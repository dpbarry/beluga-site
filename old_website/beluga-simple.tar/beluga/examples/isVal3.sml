term : type.
lam  : (term -> term) -> term.
app  : term -> term -> term.

boolean : type.
tt      : boolean.
ff      : boolean.

rec isVal : {g:term} term[g] -> boolean[ ] =
FN g => fn t => 
   (case t of
        box(g . U[.])     => box( . tt)
      | box(g . U[id(g)]) => box( . ff));
