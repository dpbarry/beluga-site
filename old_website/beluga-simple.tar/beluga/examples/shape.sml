term : type.
lam  : (term -> term) -> term.
app  : term -> term -> term.

tm    : type.
fun   : (tm -> tm) -> tm.
apply : tm -> tm -> tm.

boolean  : type.
tt  : boolean.
ff  : boolean.


rec ANDALSO : boolean[ ] -> boolean[ ] -> boolean[ ] = 
fn E => fn F =>
   (case E of 
        box( . tt) => F 
      | box( . ff) => E);

rec shape : {g:term}{l:tm} term[g] -> tm[l] -> boolean[ ] =
FN g => FN l => fn e => fn t => 
   (case e of
        box(g . p[id(g)])    => 
        (case t of
             box(l . q[id(l)]) => box( . tt)
           | box(l . U[id(l)]) => box( . ff))
      | box(g . lam (\x . U[id(g), x])) => 
        (case t of
             box(l . fun (\x. V[id(l),x])) 
             => shape [g,x:term]  [l,x:tm] box(g,x . U[id(g), x]) box(l,x . V[id(l), x])
           | box(l . U[id(l)]) => box( . ff))

      | box(g . (app U[id(g)]) W[id(g)]) => 
        (case t of box(l . (apply E[id(l)]) F[id(l)]) => 
	               (ANDALSO ((shape [g] [l] box(g . U[id(g)]))  box(l . E[id(l)])))
                       ((shape [g] [l] box(g . W[id(g)])) box(l . F[id(l)]))
                 | box(l . E[id(l)]) => box( . ff))
      | box(g . U[id(g)]) => box( . ff));
