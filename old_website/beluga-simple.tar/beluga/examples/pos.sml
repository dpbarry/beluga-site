(* Context inspection; doesn't typecheck. *)

nat: type.
z : nat.
s : nat -> nat.

(* exp : type of hoas terms *)
exp: type.
lam : (exp -> exp) -> exp.
app : exp -> exp -> exp.

rec inc : nat[ ] -> nat[ ] =
  fn n =>
  let val box(. N[.]) = n
  in box(. s N[.]) end
;

rec pos : {g:exp} exp[g] -> nat[ ] =
 FN g => fn exp =>
   case exp of
       box (g', x. x) => box (. z)          (* needs to equate   g = (g', x) *)
    |  box (g', x. P[id(g')]) => inc (pos [g'] box(g'. P[id(g')]))
;
(*
rec pos : {g:exp} exp[g] -> nat[ ] =
  FN g = fn exp =>
    case g of
        g', x =>
             case exp of
                 box(g', x. x) => box ( z)
               | box(g', x. P[id(g')]) => inc (pos [g'] box(g'. P[id(g')]))
;
*)
(*
TODO: translate the following
(* g[g] * exp[g] -> [g']g where g' <= g *) (* preceding comment possibly misplaced *)

 {g:exp} {g':exp} exp[g] -> exp[g'] -> g[g']  where g <= g'
fun update  (box g,x. x ) (box g'. u[id(g')]) =
       (sbox g'. id(g), u[id(g')])
  | update (box g,x. p[id(g)]) (box g'.u[id(g')]) =

    let sbox g'. s' = update (box g.p[id(g)]), box (g'. u[id(g)]))
    in
      (sbox g'. s'[id(g')], x)

 {g}{g'} g'[g] -> exp[g] -> g'[g]
 fun upsub (sbox g. s[id(g)], p[id(g)] : (g',y)) 1 (box g.u[id(g)]) =
           box(g. s[id(g)], u[id(g)])
     | upsub (sbox g.s[id(g)], p[id(g)] : (g',y)) n e =
       let
         sbox(g.s'[id(g)]) = upsub [g]  (sbox g. s[id(g)]) (n-1) e
       in
          sbox(g. s'[id(g)], p[id(g)])
       end
*)
