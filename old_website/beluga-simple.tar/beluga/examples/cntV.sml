(* Variable counting (see Pientka [POPL'08])
   Author:  Brigitte Pientka

   This example only uses weak higher-order abstract
   syntax.
*)

exp: type.
Nat: nat -> exp.
Add: exp -> exp -> exp.
Let: exp -> (nat -> exp) -> exp.

nat: type.
z  : nat.
suc: nat -> nat.

rec cntV : {g:nat} exp[g, x:nat] -> int =
FN g => fn e => 
           (case e of
               box(g,x . Nat U[id(g)]) => 0
             | box(g,x . Nat U[. , x]) => 1
             | box(g,x . Let U1[id(g), x] (\y . U2[id(g), x, y])) =>
               cntV [g] box(g,x . U1[id(g), x]) + cntV [g, y:nat] box(g,y,x . U2[id(g), x, y])
             | box(g,x . Add U[id(g), x] W[id(g), x]) =>
               cntV [g] box(g,x . U[id(g), x]) + cntV [g] box(g,x . W[id(g), x]));

cntV [] box(x . Nat z);
cntV [] box(x . Nat x);
cntV [] box(x . Add (Nat z) (Nat x));
cntV [] box(x . Add (Nat x) (Nat z));
cntV [] box(x . Add (Nat x) (Nat x));
cntV [] box(x . Let (Nat z) (\y . Nat y));
cntV [] box(x . Let (Add (Nat z) (Nat x)) (\a . Add (Nat x) (Nat a)));
