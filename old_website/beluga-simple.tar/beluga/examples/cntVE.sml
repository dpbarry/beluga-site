(* Variable counting (see Pientka [POPL'08])
   Author:  Brigitte Pientka

   This example uses full higher-order abstract
   syntax.
*)
exp: type.
z  : exp.
suc: exp -> exp.
Add: exp -> exp -> exp.
Let: exp -> (exp -> exp) -> exp.


rec cntVE : {g:exp} exp[g, x:exp] -> int =
FN g => fn e => 
(case e of
   box(g,x . z) => 0
 | box(g,x . p[id(g)]) => 0
 | box(g,x . x) => 1
 | box(g,x . suc U[id(g), x]) => cntVE [g] box(g,x. U[id(g), x])
 | box(g,x . (Add U[id(g), x]) W[id(g), x]) =>
     cntVE [g] box(g,x . U[id(g), x]) + 
     cntVE [g] box(g,x . W[id(g), x])
 | box(g,x . (Let U1[id(g), x]) (\y . U2[id(g), y, x])) =>
     cntVE [g] box(g,x . U1[id(g), x]) +
     cntVE [g, y:exp] box(g,y,x . U2[id(g), y, x])
)
;
