(* First-order names to higher-order names *) 

fname : type.

(* fname: type of First-order names; should just be `string'... *)
z : fname.
s : fname -> fname.

(* exp : type of hoas terms *)
exp: type.
lam : (exp -> exp) -> exp.
app : exp -> exp -> exp.

(* fexp : type of first-order terms with fnames *)
fexp: type.
fvar : fname -> fexp.
flam : fname -> fexp -> fexp.
fapp : fexp -> fexp -> fexp.

(* list : cons(n1, x1, cons(n2, x2, nil)) represents the map {n1 |-> x1, n2 |-> x2} *)
list: type.
nil : list.
cons : fname -> exp -> list -> list.

exp_option: type.
NONE : exp_option.
SOME : exp -> exp_option.

(*
(* lookup: name[] * list[g] -> exp[g] option*)
fun lookup [g] (n as (box . u[])) (box g. cons(v[], p[id(g)], l[id(g)])) =
   if  (box . u[]) = (box . v[]) then SOME (box g.p[id(g)])
   else
      lookup [g] n (box g. l[id(g)])
    | lookup [g] n (box g. nil) = NONE
*)

rec lookup : {g : exp} fname[ ] -> list[g] -> exp_option[g] =
  FN g => fn fname => fn list =>
     case list of
         box(g. cons V[.] P[id(g)] Tail[id(g)]) =>
             if fname = box(. V[.]) then box(g. SOME P[id(g)])
             else lookup [g] fname box(g.Tail[id(g)])
;

(* f2h assumes no free first-order names in input `fexp' *)
rec f2h : {g : exp} fexp[ ] -> list[g] -> exp[g] =
  FN g => fn fexp => fn list => case list of box(g. l[id(g)]) =>
     case fexp of
         box( . flam (N[.]) (E[.])) =>
             let val box (g, x. U[id(g), x]) = f2h [g, x:exp] box(. E[.]) box(g, x. cons N[.] x l[id(g)])
             in
                 box (g. lam \x. U[id(g), x])
             end
       | box( . fvar (N[.])) =>
             (case lookup [g] box(. N[.]) list of
                 box(g. SOME P[id(g)]) => box(g. P[id(g)])
               | box(g. NONE) => f2h [g] fexp list   (* should be: raise Error *)
             )
       | box( . fapp E1[.] E2[.]) =>
             let
               val box (g.U[id(g)]) = f2h [g] box(. E1[.]) list
               val box (g.V[id(g)]) = f2h [g] box(. E2[.]) list
             in
               box (g. app U[id(g)] V[id(g)])
             end
;
