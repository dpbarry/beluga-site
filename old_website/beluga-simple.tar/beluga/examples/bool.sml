(* Simple boolean operations. 
   Author: Brigitte Pientka
*)
boolean  : type.
tt  : boolean.
ff  : boolean.

rec ANDALSO : boolean[ ] -> boolean[ ] -> boolean[ ] = 
fn E => fn F =>
 (case E of 
   box( . tt) => (case F of box( . tt) => box( . tt) | box( . ff) => box( . ff))
 | box( . ff) => (case F of box( . tt) => box( . ff) | box( . ff) => box( . ff))
);


rec ANDALSO2 : boolean[ ] -> boolean[ ] -> boolean[ ] = 
fn E => fn F =>
 (case E of 
   box( . tt) => F 
 | box( . ff) => E
);

rec ORELSE : boolean[ ] -> boolean[ ] -> boolean[ ] = 
fn E => fn F =>
 (case E of 
   box( . tt) =>  box( . tt)
 | box( . ff) => (case F of box( . tt) => box( . tt) | box( . ff) => box( . ff))
);

rec ORELSE2 : boolean[ ] -> boolean[ ] -> boolean[ ] = 
fn E => fn F =>
 (case E of 
   box( . tt) => E
 | box( . ff) => F 
);

