term: type.
lam : (term -> term) -> term.
app : term -> term -> term.

rec equal : {g : term} (term * term)[g] -> bool =
FN g => fn t =>
(case t of
     box(g . (p[id(g)], p'[id(g)])) 
     => boxeq([g], box(g . p[id(g)]), box(g . p'[id(g)]))
   | box(g . (lam \x . U[id(g), x], lam \x . U'[id(g), x]))
     => equal [g,x:term] box(g,x . (U[id(g), x], U'[id(g), x]))
   | box(g . (app U[id(g)] U'[id(g)], app W[id(g)] W'[id(g)]))
     => equal [g] box(g . (U[id(g)], W[id(g)])) andalso
        equal [g] box(g . (U'[id(g)], W'[id(g)]))
   | box(g . U[id(g)]) => false);

equal [] box(. (app (lam \x . x) (lam \y . y), app (lam \x . x) (lam \x . x)));
equal [] box(. (lam \x . lam \y . x, lam \x . lam \y . x));
equal [] box(. (lam \x . lam \y . y, lam \x . lam \y . x));
