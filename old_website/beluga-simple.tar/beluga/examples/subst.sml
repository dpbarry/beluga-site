exp: type.

rec subst: {g: exp} exp[g, x:exp] -> exp[ ] -> exp[g] =
FN g => fn e => fn m =>
let
    val box(. W[.]) = m 
in
    (case e of box(g,x. U[id(g), x]) => box(g . U[id(g), W[.]]))
end;

rec subst': {g: exp} exp[g, x:exp] -> exp[g] -> exp[g] =
FN g => fn e => fn m =>
let 
    val box(g . W[id(g)]) = m 
in
    (case e of box(g,x. U[id(g), x]) => box(g . U[id(g), W[id(g)]]))
end;
