(* Simple arithmetic operations
   Author: Brigitte Pientka
*)
nat: type.
z  : nat.
suc: nat -> nat.

rec add : nat[ ] -> nat[ ] -> nat[ ] = 
fn a => fn b =>
   (case a of
        box( . z) => b
      | box( . suc U[.]) =>
        (case b of
             box( . V[.]) => (add box( . U[.])) box( . suc V[.])
       )
);


rec mult : nat [ ] -> nat [ ] -> nat [ ] = 
fn a => fn b => 
 (case a of 
   box( . z) => a
 | box( . suc(U[.])) => (add b) ((mult box( . U[.])) b))
;


rec min : nat [ ] -> nat [ ] -> nat [ ] = 
fn a => fn b => 
 (case a of 
   box( . z) => a
 | box( . suc U[.]) => 
   (case b of box( . z) => a
            | box( . suc V[.]) => (min box( . U[.])) box( . V[.])
    )
 );

