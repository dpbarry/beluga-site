(* Substitution based evaluator
   call-by-value strategy

   Author: Brigitte Pientka
*)

exp: type.
Nat: nat -> exp.
Add: exp -> exp -> exp.
Let: exp -> (nat -> exp) -> exp.

nat: type.
z  : nat.
suc: nat -> nat.

rec add : nat[ ] -> nat[ ] -> nat[ ] = 
fn a => fn b =>
   (case a of
        box( . z) => b
      | box( . suc U[.]) =>
        (case b of
             box( . V[.]) => (add box( . U[.])) box( . suc V[.])
       )
);

rec eval : exp[ ] -> nat[ ] = 
fn e => 
(case e of
   box( . Nat U[.]) => box( . U[.])
 | box( . (Add U[.]) W[.]) => 
   add (eval box( . U[.])) (eval box( . W[.]))
 | box( . (Let U[.]) (\x . W[. , x])) => 
   let val box( . V[.]) = eval box( . U[.]) in eval box( . W[. , V[.]]) end
);
