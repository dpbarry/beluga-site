nat: type.
z  : nat.
suc: nat -> nat.

rec cntVNat' : {g:nat} nat[g, x:nat] -> int =
FN g => fn n => 
(case n of
   box(g,x . p[id(g)]) => 0
 | box(g,x . p[. , x]) => 1
 | box(g,x . suc  U[id(g), x]) => 
     cntVNat' [g] box(g,x. U[id(g), x]));

