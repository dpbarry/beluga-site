nat : type.
z   : nat.
suc : nat -> nat.

opt: type.
none: opt.
some: nat -> opt.

rec isVal : {g:nat} nat[g] -> opt[ ] =
FN g => fn n =>
   (case n of
        box(g . U[.])     => box( . some U[.])
      | box(g . U[id(g)]) => box( . none));
