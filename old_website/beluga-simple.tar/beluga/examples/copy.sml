term : type.
Lam  : (term -> term) -> term.

rec copy : {g: term} term[g] -> term[g] =
FN g => fn e => 
(case e of
     box(g . p[id(g)]) => box(g.p[id(g)])
   | box(g . Lam (\x. U[id(g), x])) =>
     (case copy [g, x:term] box(g,x . U[id(g), x]) of
          box(g,x . V[id(g), x]) =>   box (g . Lam \x. V[id(g) , x])));
