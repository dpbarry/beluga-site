term: type.
lam : (term -> term) -> term.
app : term -> term -> term.

rec equal : {g:term} term[g] -> term[g] -> bool =
FN g => fn t1 => fn t2 => 
(case t1 of
     box(g . p[id(g)]) => 
     (case t2 of
          box(g . p'[id(g)]) => boxeq([g], box(g . p[id(g)]), box(g . p'[id(g)])))

   | box(g . lam \x . E[id(g), x]) => 
     (case t2 of 
          box(g . lam \x . E'[id(g), x]) =>
          (equal [g,x:term] box(g,x . E[id(g), x])) box(g,x . E'[id(g), x]))
     
   | box(g . (app U[id(g)]) U'[id(g)]) => 
     (case t2 of 
          box(g . (app W[id(g)]) W'[id(g)]) =>
          (equal [g] box(g . U[id(g)])) box(g . W[id(g)]) andalso
          (equal [g] box(g . U'[id(g)])) box(g . W'[id(g)])));
