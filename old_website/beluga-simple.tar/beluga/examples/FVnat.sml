nat : type.
z   : nat.
suc : nat -> nat.

opt: type.
NONE: opt.
SOME: nat -> opt.

rec FVnat : {g:nat} nat[g] -> opt[g] =
FN g => fn e => 
(case e of
  box(g . z)           => box(g . NONE)
| box(g . p[id(g)])     => box(g . SOME  p[id(g)])
| box(g . suc U[id(g)]) => FVnat [g] (box(g . U[id(g)]))
);
