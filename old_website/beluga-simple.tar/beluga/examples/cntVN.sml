nat : type.
z   : nat.
suc : nat -> nat.

rec cntVN : {g:nat} nat[g] -> nat[g] -> int =
FN g => fn n => fn x => 
let 
    val box(g . p'[id(g)]) = x
in
    (case n of
         box(g . z) => 0
       | box(g . p[id(g)]) =>
         if boxeq([g], box(g . p'[id(g)]), box(g . p[id(g)])) then 1 else 0
       | box(g . suc U[id(g)]) => (cntVN [g] box(g . U[id(g)])) x)
end;

cntVN [x:nat, y:nat] box(x, y . z) box(x, y . x);
cntVN [x:nat, y:nat] box(x, y . x) box(x, y . x);
cntVN [x:nat, y:nat] box(x, y . y) box(x, y . x);
cntVN [x:nat, y:nat] box(x, y . suc (suc z)) box(x, y . x);
cntVN [x:nat, y:nat] box(x, y . suc (suc x)) box(x, y . x);
cntVN [x:nat, y:nat] box(x, y . suc (suc y)) box(x, y . x);
