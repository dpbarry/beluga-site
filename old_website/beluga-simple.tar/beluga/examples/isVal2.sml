nat : type.
z   : nat.
suc : nat -> nat.

boolean : type.
tt      : boolean.
ff      : boolean.

rec isVal : {g:nat} nat[g] -> boolean[ ] =
FN g => fn n => 
   (case n of
        box(g . U[.])    => box( . tt)
      | box(g . U[id(g)]) => box( . ff));
