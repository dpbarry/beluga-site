(* -*- sml-lex -*- *)

structure Tokens = Tokens
type pos = int
type svalue = Tokens.svalue
type ('a, 'b) token = ('a, 'b) Tokens.token
type lexresult = (svalue, pos) token
type lexarg = {pos : int ref, lin : int ref, depth : int ref, fileName : string}
type arg = lexarg

(*val pos   = ref 0
val lin   = ref 1
val depth = ref 0*)
val eof   = fn {fileName, pos, lin, depth} => Tokens.EOF(!lin,0)
(*  (pos := 0;
   lin := 1;
   depth := 0)
*)

%%
%full
%header (functor fphoasLexFun(structure Tokens: fphoas_TOKENS));
%arg ({pos, lin, depth, fileName});
%s FPHOAS COMMENT;

alpha = [A-Za-z];
digit = [0-9];
name  = {alpha}({alpha}|{digit}|_|')*;
ws    = [\ \t];
eol   = ("\013\010"|"\010"|"\013");

%%
<INITIAL>{ws}* => (YYBEGIN FPHOAS; continue());
<FPHOAS>{ws}*  => (continue());
<FPHOAS>{eol}  => (lin:=(!lin)+1; continue());

"(*"           => (YYBEGIN COMMENT; depth:=(!depth)+1; continue());
<COMMENT>"*)"  => (depth:=(!depth)-1; if !depth = 0 then YYBEGIN FPHOAS else YYBEGIN COMMENT; continue());
<COMMENT>{eol} => (lin:=(!lin)+1; continue());
<COMMENT>.     => (continue());

<FPHOAS>":"       => (Tokens.COLON(!lin,0));
<FPHOAS>";"       => (Tokens.SEMICOLON(!lin,0));
<FPHOAS>"="       => (Tokens.EQUAL(!lin,0));
<FPHOAS>"val"     => (Tokens.VAL(!lin,0));
<FPHOAS>"rec"     => (Tokens.REC(!lin,0));
<FPHOAS>"box"     => (Tokens.BOX(!lin,0));
<FPHOAS>"boxeq"   => (Tokens.BOXEQ(!lin,0));
<FPHOAS>"sbox"    => (Tokens.SBOX(!lin,0));
<FPHOAS>"let"     => (Tokens.LET(!lin,0));
<FPHOAS>"in"      => (Tokens.IN(!lin,0));
<FPHOAS>"end"     => (Tokens.END(!lin,0));
<FPHOAS>"if"      => (Tokens.IF(!lin,0));
<FPHOAS>"then"    => (Tokens.THEN(!lin,0));
<FPHOAS>"else"    => (Tokens.ELSE(!lin,0));
<FPHOAS>"case"    => (Tokens.CASE(!lin,0));
<FPHOAS>"of"      => (Tokens.OF(!lin,0));
<FPHOAS>"|"       => (Tokens.BAR(!lin,0));
<FPHOAS>"fst"     => (Tokens.FST(!lin,0));
<FPHOAS>"snd"     => (Tokens.SND(!lin,0));
<FPHOAS>"FN"      => (Tokens.FNC(!lin,0));
<FPHOAS>"fn"      => (Tokens.FN(!lin,0));
<FPHOAS>"("       => (Tokens.LPAREN(!lin,0));
<FPHOAS>")"       => (Tokens.RPAREN(!lin,0));
<FPHOAS>"["       => (Tokens.LBRACKET(!lin,0));
<FPHOAS>"]"       => (Tokens.RBRACKET(!lin,0));
<FPHOAS>"{"       => (Tokens.LBRACE(!lin,0));
<FPHOAS>"}"       => (Tokens.RBRACE(!lin,0));
<FPHOAS>"."       => (Tokens.DOT(!lin,0));
<FPHOAS>"->"      => (Tokens.ARROW(!lin,0));
<FPHOAS>"=>"      => (Tokens.DARROW(!lin,0));
<FPHOAS>"true"    => (Tokens.BOOLEAN(true,!lin,0));
<FPHOAS>"false"   => (Tokens.BOOLEAN(false,!lin,0));
<FPHOAS>"+"       => (Tokens.ADD(!lin,0));
<FPHOAS>"-"       => (Tokens.SUB(!lin,0));
<FPHOAS>"*"       => (Tokens.STAR(!lin,0));
<FPHOAS>"/"       => (Tokens.DIV(!lin,0));
<FPHOAS>"andalso" => (Tokens.ANDALSO(!lin,0));
<FPHOAS>"orelse"  => (Tokens.ORELSE(!lin,0));
<FPHOAS>"not"     => (Tokens.NOT(!lin,0));
<FPHOAS>","       => (Tokens.COMMA(!lin,0));
<FPHOAS>"_"       => (Tokens.UNDERSCORE(!lin,0));
<FPHOAS>"\\"      => (Tokens.BACKSLASH(!lin,0));
<FPHOAS>"type"    => (Tokens.TYPE(!lin,0));
<FPHOAS>"id"      => (Tokens.IDENT(!lin,0));
<FPHOAS>"int"     => (Tokens.INT(!lin,0));
<FPHOAS>"bool"    => (Tokens.BOOL(!lin,0));
<FPHOAS>{digit}+  => (Tokens.NUM(foldl (fn (a,r) => ord(a) - ord(#"0") + 10 * r) 0 (explode yytext),!lin,0));
<FPHOAS>{name}    => (Tokens.NAME(yytext,!lin,0));
<FPHOAS>{eol}     => (lin:=(!lin)+1; continue());
<FPHOAS>.         => (print ("syntax error: " ^ yytext ^ "\n"); continue());
