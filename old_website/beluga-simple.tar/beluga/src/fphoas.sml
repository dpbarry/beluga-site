structure fphoasLrVals = fphoasLrValsFun(structure Token = LrParser.Token);
structure fphoasLex = fphoasLexFun(structure Tokens = fphoasLrVals.Tokens);
structure fphoasParser = JoinWithArg (structure ParserData = fphoasLrVals.ParserData
structure Lex = fphoasLex
structure LrParser = LrParser);

structure Fphoas : sig
    datatype result = SyntaxError | TypeError | NameError | RuntimeError | Success
    val run          : string -> result
    val standardTest : unit -> bool
    val test         : (string * result) list -> bool
end
  = struct

open DataTypes
open TypeChecker
open Evaluator

datatype result = SyntaxError | TypeError | NameError | RuntimeError | Success

fun resultToString SyntaxError  = "SyntaxError"
  | resultToString TypeError    = "TypeError"
  | resultToString NameError    = "NameError"
  | resultToString RuntimeError = "RuntimeError"
  | resultToString Success      = "Success"

exception FphoasError of string

fun run (fileName) =
    let val inStream = TextIO.openIn fileName
        val _ = print ("\tParsing " ^ fileName ^ "\n")
        val grab : int -> string = 
         fn n => if TextIO.endOfStream inStream then "" else TextIO.inputN (inStream,n)
        val printError : string * int * int -> unit = 
         fn (msg,line,col) => print (fileName^"["^Int.toString line^":"^Int.toString col^"] "^msg^"\n")
        val lexarg = {pos= ref 0, lin= ref 1, depth= ref 0, fileName= fileName}
    in
        let val (tree,rem) = fphoasParser.parse (0, (fphoasParser.makeLexer grab) lexarg, printError, fileName)
            (* val _ = print ("PROGRAM: \n" ^ Pretty.prog2str tree ^ "\n\n") *)
            (* handle fphoasParser.ParseError => raise FphoasError*)
            val _ = TextIO.closeIn inStream;
            val _ = print ("\tChecking " ^ fileName ^ "\n")
        in 
            (typecheck(tree); eval(tree); Success)
        end
        handle typeCheckError(x)                  => (print("Type Check Error: " ^ x ^ "\n"); TypeError)
             | undefinedName(x)                   => (print("Undefined name: " ^ x ^ "\n"); NameError)
             | runtimeError(x)                    => (print("Runtime error: " ^ x ^ "\n"); RuntimeError)
             | fphoasParser.ParseError            => (print("Parse error" ^ "\n"); SyntaxError)
             | Precedence.OperatorPrecedenceError => (print("Parse error" ^ "\n"); SyntaxError)
    end

fun test [] = true
  | test ((pathname, correctResult) :: rest) =
    let val actualResult = run pathname
        val thisOK = (actualResult = correctResult)
        val _ = if not thisOK
                then print ("*** Result for "  ^ pathname ^ ", " ^ resultToString actualResult ^
                            ",  does not match expected result " ^ resultToString correctResult
                            ^ "\n")
                else ()
        val restOK = test rest     (* always run all tests, even if one fails *)
    in
        thisOK andalso restOK
    end

val standardNames = 
    [("FVnat.sml",        Success),
     ("arith.sml",        Success),
     ("bool.sml",         Success),
     ("cntV.sml",         Success),
     ("cntVE.sml",        Success),
     ("cntVN.sml",        Success),
     ("cntVnat.sml",      Success), 
     ("cntVnat2.sml",     Success),
     ("copy.sml",         Success),
     ("equal.sml",        Success),
     ("equal2.sml",       Success),
     ("eval-sub.sml",     Success),
     ("isVal.sml",        Success),
     ("isVal2.sml",       Success),
     ("isVal3.sml",       Success),
     ("shape.sml",        Success),
     ("subst.sml",        Success),
     ("f2h.sml",          Success),
     ("pos.sml",          TypeError),

     ("regression-testing/eq.sml",                TypeError),
     ("regression-testing/isValWRONG.sml",        TypeError),
     ("regression-testing/eval-sub2.sml",         TypeError),
     ("regression-testing/eval.sml",              TypeError),
     ("regression-testing/shape2.sml",            TypeError),
     ("regression-testing/shape3.sml",            TypeError),
     ("regression-testing/syntax-assoc-data.sml", TypeError),
     ("regression-testing/syntax-assoc.sml",        Success),
     ("regression-testing/testWRONG.sml",         TypeError)
    ]

fun standardTest () =
    let val standardPaths = map (fn (name, correctResult) => ("../examples/" ^ name, correctResult)) standardNames
    in
        test standardPaths
    end
end
