structure Evaluator : sig 
    exception runtimeError of string
    val eval : DataTypes.prog  -> unit
end
  = struct

open DataTypes
open Pretty

exception runtimeError of string
exception failedMatch
exception notFound

(* utility functions *)
fun nth (0, SubM(sigma, M))                    = M
  | nth (0, SubR(sigma, R))                    = Neutr(R)
  | nth (i, (SubM(sigma, _) | SubR(sigma, _))) = nth(i - 1, sigma)
  | nth (i, sigma)                             = raise runtimeError("unexpected")

fun first_substitution_element (x as (Snull | Id(_) | Svar(_, _)))  = x
  | first_substitution_element (SubM(sigma, _) | SubR(sigma, _))    = first_substitution_element(sigma)

fun get (name, (repl, n) :: tail) = if name = n then repl else get(name, tail)
  | get (name, []) = raise notFound

fun isValue (Fn(_, _) | Fnc(_, _) | Box(_, _) | Sbox(_, _) | Num(_) | Boolean(_)) = true
  | isValue (_) = false

fun shift_normal (d, c, Lambda(y, M)) = Lambda(y, shift_normal(d, c + 1, M))
  | shift_normal (d, c, Pair(M, N))   = Pair(shift_normal(d, c, M), shift_normal(d, c, N))
  | shift_normal (d, c, Neutr(R))     = Neutr(shift_neutral(d, c, R))
and shift_neutral (d, c, Ovar(x, i))     = if i < c then Ovar(x, i) else Ovar(x, i + d)
  | shift_neutral (d, c, Mvar(u, sigma)) = Mvar(u, shift_substitution(d, c, sigma))
  | shift_neutral (d, c, Pvar(p, sigma)) = Pvar(p, shift_substitution(d, c, sigma))
  | shift_neutral (d, c, App(R, N))      = App(shift_neutral(d, c, R), shift_normal(d, c, N))
  | shift_neutral (d, c, Fst(R))         = Fst(shift_neutral(d, c, R))
  | shift_neutral (d, c, Snd(R))         = Snd(shift_neutral(d, c, R))
  | shift_neutral (d, c, Const(c'))      = Const(c')
and shift_substitution (d, c, Snull)          = Snull
  | shift_substitution (d, c, SubM(sigma, M)) = SubM(shift_substitution(d, c, sigma), shift_normal(d, c, M))
  | shift_substitution (d, c, SubR(sigma, R)) = SubR(shift_substitution(d, c, sigma), shift_neutral(d, c, R))
  | shift_substitution (d, c, Svar(s, sigma)) = Svar(s, shift_substitution(d, c, sigma))
  | shift_substitution (d, c, Id(psi))        = Id(psi)

fun id (Cnull, i)            = Snull
  | id (Cvar(psi), i)        = Id(psi)
  | id (Ctx(Psi, (x, A)), i) = SubR(id(Psi, i + 1), Ovar(x, i))

fun closed_neutral (App(R, N), pi)                        = closed_neutral(R, pi) andalso closed_normal(N, pi)
  | closed_neutral ((Fst(R) | Snd(R)), pi)                = closed_neutral(R, pi)
  | closed_neutral (Const(c), pi)                         = true
  | closed_neutral ((Mvar(_, _) | Pvar(_, _)), pi)        = raise runtimeError("unexpected")
  | closed_neutral (ovar, (Snull | Svar(_, _) | Id(_)))   = false
  | closed_neutral (ovar, SubM(sigma, M))                 = closed_neutral(ovar, sigma)
  | closed_neutral (Ovar(x, i), SubR(sigma, Ovar(y, i'))) = (i = i') orelse closed_neutral(Ovar(x, i), sigma)
  | closed_neutral (ovar, SubR(sigma, R))                 = closed_neutral(ovar, sigma)
and closed_normal (Lambda(y, M), pi) = closed_normal(M, SubR(shift_substitution(1, 0, pi), Ovar(y, 0)))
  | closed_normal (Pair(M, N), pi)   = closed_normal(M, pi) andalso closed_normal(N, pi)
  | closed_normal (Neutr(R), pi)     = closed_neutral(R, pi)

fun equal_neutral (Ovar(x, i), Ovar(y, j))    = (i = j)
  | equal_neutral (App(R1, N1), App(R2, N2))  = equal_neutral(R1, R2) andalso equal_normal(N1, N2)
  | equal_neutral (Fst(R1), Fst(R2))          = equal_neutral(R1, R2)
  | equal_neutral (Snd(R1), Snd(R2))          = equal_neutral(R1, R2)
  | equal_neutral (Const(c1), Const(c2))      = (c1 = c2)
  | equal_neutral (_)                         = false
and equal_normal (Lambda(x, N), Lambda(y, M)) = equal_normal(N, M)
  | equal_normal (Pair(M1, N1), Pair(M2, N2)) = equal_normal(M1, M2) andalso equal_normal(N1, N2)
  | equal_normal (Neutr(R1), Neutr(R2))       = equal_neutral(R1, R2)
  | equal_normal (_)                          = false

(* SUBSTITUTION *)
(* context variable *)
fun substitute_cvar_exp (Psi, psi, exp) =
    case exp of 
        Var(x)        => Var(x)
      | Rec(f, e)     => Rec(f, substitute_cvar_exp(Psi, psi, e))
      | Fn(y, e)      => Fn(y, substitute_cvar_exp(Psi, psi, e))
      | Fnc(psi', e)  => if psi = psi' then Fnc(psi', e) else Fnc(psi', substitute_cvar_exp(Psi, psi, e))
      | Box(names, M) =>
        let
            val names' = substitute_cvar_hat(Psi, psi, names)
        in
            Box(names', substitute_cvar_normal(Psi, psi, M, length(names) - 1))
        end
      | Sbox(names, sigma) => 
        let
            val names' = substitute_cvar_hat(Psi, psi, names)
        in
            Sbox(names', substitute_cvar_substitution(Psi, psi, sigma, length(names) - 1))
        end
      | Capp(e1, e2)         => Capp(substitute_cvar_exp(Psi, psi, e1), substitute_cvar_exp(Psi, psi, e2))
      | Appc(e, Psi')        => Appc(substitute_cvar_exp(Psi, psi, e), substitute_cvar_context(Psi, psi, Psi'))
      | Aexp(e, tau)         => Aexp(substitute_cvar_exp(Psi, psi, e), tau)
      | Case(e, branches)    => Case(substitute_cvar_exp(Psi, psi, e), map (fn b => substitute_cvar_branch(Psi, psi, b)) branches)
      | Let((x, e), e')      => Let((x, substitute_cvar_exp(Psi, psi, e)), substitute_cvar_exp(Psi, psi, e'))
      | If(e1, e2, e3)       => If(substitute_cvar_exp(Psi, psi, e1), substitute_cvar_exp(Psi, psi, e2), substitute_cvar_exp(Psi, psi, e3))
      | Op(p, exps)          => Op(p, map (fn e => substitute_cvar_exp(Psi, psi, e)) exps)
      | Equalp(e1, e2, Psi') => Equalp(substitute_cvar_exp(Psi, psi, e1), substitute_cvar_exp(Psi, psi, e2), substitute_cvar_context(Psi, psi, Psi'))
      | Num(i)               => Num(i)
      | Boolean(b)           => Boolean(b)
and substitute_cvar_context (Psi, psi, exp) =
    case exp of
        Cnull             => Cnull
      | Cvar(psi')        => if psi = psi' then Psi else Cvar(psi')
      (* REM x could happen in Psi but we're using indices ... *)
      | Ctx(Psi', (x, A)) => Ctx(substitute_cvar_context(Psi, psi, Psi'), (x, A))
and substitute_cvar_branch (Psi, psi, Bbranch(names, M, e))     = 
    let 
        val names' = substitute_cvar_hat(Psi, psi, names)
    in 
        (* REM "-1" if the first name is a Cvar, else it doesn't matter since we don't unroll anything *)
        Bbranch(names', substitute_cvar_normal(Psi, psi, M, length(names) - 1), substitute_cvar_exp(Psi, psi, e))
    end
  | substitute_cvar_branch (Psi, psi, Sbranch(names, sigma, e)) = 
    let
        val names' = substitute_cvar_hat(Psi, psi, names)
    in
        Sbranch(names', substitute_cvar_substitution(Psi, psi, sigma, length(names) - 1), substitute_cvar_exp(Psi, psi, e))
    end
and substitute_cvar_normal (Psi, psi, exp, i) =
    case exp of
        Lambda(x, M) => Lambda(x, substitute_cvar_normal(Psi, psi, M, i + 1))
      | Pair(M, N)   => Pair(substitute_cvar_normal(Psi, psi, M, i), substitute_cvar_normal(Psi, psi, N, i))
      | Neutr(R)     => Neutr(substitute_cvar_neutral(Psi, psi, R, i))
and substitute_cvar_neutral (Psi, psi, exp, i) =
    case exp of
        Ovar(x, i')    => Ovar(x, i')
      | Mvar(u, sigma) => Mvar(u, substitute_cvar_substitution(Psi, psi, sigma, i))
      | Pvar(p, sigma) => Pvar(p, substitute_cvar_substitution(Psi, psi, sigma, i))
      | App(R, N)      => App(substitute_cvar_neutral(Psi, psi, R, i), substitute_cvar_normal(Psi, psi, N, i))
      | Fst(R)         => Fst(substitute_cvar_neutral(Psi, psi, R, i))
      | Snd(R)         => Snd(substitute_cvar_neutral(Psi, psi, R, i))
      | Const(c)       => Const(c)
and substitute_cvar_substitution (Psi, psi, exp, i) =
    case exp of
        Snull          => Snull
      | SubM(sigma, M) => SubM(substitute_cvar_substitution(Psi, psi, sigma, i), substitute_cvar_normal(Psi, psi, M, i))
      | SubR(sigma, R) => SubR(substitute_cvar_substitution(Psi, psi, sigma, i), substitute_cvar_neutral(Psi, psi, R, i))
      | Svar(s, rho)   => Svar(s, substitute_cvar_substitution(Psi, psi, rho, i))
      | Id(phi)        => if phi = psi then id(Psi, i) else Id(phi)
and substitute_cvar_hat (Psi, psi, names) =
    let
        fun unroll (Cnull)            = []
          | unroll (Cvar(psi))        = raise runtimeError("unexpected") (* REM should never happen *)
          | unroll (Ctx(Psi, (x, A))) = x :: unroll(Psi)
        fun substitute (Psi, psi, [])      = []
          | substitute (Psi, psi, [n])     = if psi = n then unroll(Psi) else [n]
          | substitute (Psi, psi, n :: ns) = n :: substitute(Psi, psi, ns)
    in
        rev(substitute(Psi, psi, rev(names)))
    end
        
(* computational level variable *)
fun substitute_var_exp (v, x, exp) =
    case exp of 
        Var(y)              => if x = y then v else Var(y)
      | Rec(f, e)           => if x = f then Rec(f, e) else Rec(f, substitute_var_exp(v, x, e))
      | Fn(y, e)            => if x = y then Fn(y, e) else Fn(y, substitute_var_exp(v, x, e))
      | Fnc(psi, e)         => Fnc(psi, substitute_var_exp(v, x, e))
      | Box(names, M)       => Box(names, M)
      | Sbox(names, sigma)  => Sbox(names, sigma)
      | Capp(e1, e2)        => Capp(substitute_var_exp(v, x, e1), substitute_var_exp(v, x, e2))
      | Appc(e, psi)        => Appc(substitute_var_exp(v, x, e), psi)
      | Aexp(e, tau)        => Aexp(substitute_var_exp(v, x, e), tau)
      | Case(e, branches)   => Case(substitute_var_exp(v, x, e), map (fn b => substitute_var_branch(v, x, b)) branches)
      | Let((y, e), e')     => if x = y then Let((y, e), e') else Let((y, substitute_var_exp(v, x, e)), substitute_var_exp(v, x, e'))
      | If(e1, e2, e3)      => If(substitute_var_exp(v, x, e1), substitute_var_exp(v, x, e2), substitute_var_exp(v, x, e3))
      | Op(p, exps)         => Op(p, map (fn e => substitute_var_exp(v, x, e)) exps)
      | Equalp(e1, e2, psi) => Equalp(substitute_var_exp(v, x, e1), substitute_var_exp(v, x, e2), psi)
      | Num(i)              => Num(i)
      | Boolean(b)          => Boolean(b)
and substitute_var_branch (v, x, Bbranch(names, M, e))     = Bbranch(names, M, substitute_var_exp(v, x, e))
  | substitute_var_branch (v, x, Sbranch(names, sigma, e)) = Sbranch(names, sigma, substitute_var_exp(v, x, e))

(* object level variable (ordinary substitution) *)
fun os_normal (M, i, Lambda(y, N)) = Lambda(y, os_normal(shift_normal(1, 0, M), i + 1, N))
  | os_normal (M, i, Pair(M1, M2)) = Pair(os_normal(M, i, M1), os_normal(M, i, M2))
  | os_normal (M, i, Neutr(R))     = os_neutral(M, i, R)
and os_neutral (M, i, Ovar(x, j))   = if i = j then M else Neutr(Ovar(x, j))
  | os_neutral (M, i, App(R, N))    = 
    (case os_neutral(M, i, R) of
         Lambda(y, M') => shift_normal(~1, 0, os_normal(shift_normal(1, 0, os_normal(M, i, N)), 0, M'))
       | Neutr(R')     => Neutr(App(R', os_normal(M, i, N)))
       | _             => raise runtimeError("unexpected"))
  | os_neutral (M, i, Fst(R))       = 
    (case os_neutral(M, i, R) of
         Pair(N1, N2) => N1
       | Neutr(R')    => Neutr(Fst(R'))
       | _            => raise runtimeError("unexpected"))
  | os_neutral (M, i, Snd(R))       = 
    (case os_neutral(M, i, R) of
         Pair(N1, N2) => N2
       | Neutr(R')    => Neutr(Snd(R'))
       | _            => raise runtimeError("unexpected"))
  | os_neutral (M, i, Mvar(u, rho)) = Neutr(Mvar(u, os_substitution(M, i, rho)))
  | os_neutral (M, i, Pvar(p, rho)) = Neutr(Pvar(p, os_substitution(M, i, rho)))
  | os_neutral (M, i, Const(c))     = Neutr(Const(c))
and os_substitution (M, i, Snull)        = Snull
  | os_substitution (M, i, SubM(rho, N)) = SubM(os_substitution(M, i, rho), os_normal(M, i, N))
  | os_substitution (M, i, SubR(rho, R)) = 
    (case os_neutral(M, i, R) of
         Neutr(R') => SubR(os_substitution(M, i, rho), R')
       | M'        => SubM(os_substitution(M, i, rho), M'))
  | os_substitution (M, i, Svar(s, rho)) = Svar(s, os_substitution(M, i, rho))
  | os_substitution (M, i, Id(psi))      = Id(psi)

(* simultaneous ordinary substitution *)
fun sim_os_normal (sigma, Lambda(y, N)) = Lambda(y, sim_os_normal(SubR(shift_substitution(1, 0, sigma), Ovar(y, 0)), N))
  | sim_os_normal (sigma, Pair(M, N))   = Pair(sim_os_normal(sigma, M), sim_os_normal(sigma, N))
  | sim_os_normal (sigma, Neutr(R))     = sim_os_neutral(sigma, R)
and sim_os_neutral (sigma, Ovar(x, i))   = nth(i, sigma)
  | sim_os_neutral (sigma, Mvar(u, rho)) = Neutr(Mvar(u, sim_os_substitution(sigma, rho)))
  | sim_os_neutral (sigma, App(R, N))    = 
    (case sim_os_neutral(sigma, R) of
         Lambda(y, M') => shift_normal(~1, 0, os_normal(shift_normal(1, 0, sim_os_normal(sigma, N)), 0, M'))
       | Neutr(R')     => Neutr(App(R', sim_os_normal(sigma, N)))
       | _             => raise runtimeError("unexpected"))
  | sim_os_neutral (sigma, Fst(R))       = 
    (case sim_os_neutral(sigma, R) of
         Pair(M1, M2) => M1
       | Neutr(R')    => Neutr(Fst(R'))
       | _            => raise runtimeError("unexpected"))
  | sim_os_neutral (sigma, Snd(R))       = 
    (case sim_os_neutral(sigma, R) of
         Pair(M1, M2) => M2
       | Neutr(R')    => Neutr(Snd(R'))
       | _            => raise runtimeError("unexpected"))
  | sim_os_neutral (sigma, Const(c))     = Neutr(Const(c))
  | sim_os_neutral (sigma, Pvar(p, rho)) = Neutr(Pvar(p, sim_os_substitution(sigma, rho)))
and sim_os_substitution (sigma, Snull)        = Snull
  | sim_os_substitution (sigma, SubM(rho, N)) = 
    SubM(sim_os_substitution(sigma, rho), sim_os_normal(sigma, N))
  | sim_os_substitution (sigma, SubR(rho, R)) = 
    (case sim_os_neutral(sigma, R) of 
         Neutr(R') => SubR(sim_os_substitution(sigma, rho), R')
       | M         => SubM(sim_os_substitution(sigma, rho), M))
  | sim_os_substitution (sigma, Svar(s, rho)) = Svar(s, sim_os_substitution(sigma, rho))
  | sim_os_substitution (sigma, Id(psi))      = 
    (case first_substitution_element(sigma) of
         Id(psi')            => if psi = psi' then Id(psi) else raise runtimeError("TODO2")
       | Svar(s, rho)        => Svar(s, rho)
       | Snull               => raise runtimeError("TODO3")
       | (SubM(_) | SubR(_)) => raise runtimeError("unexpected"))

(* contextual variable (simultaneous) *)
fun cs_exp (theta, Var(x))              = Var(x)
  | cs_exp (theta, Rec(f, e))           = Rec(f, e) (* FIXME should be: Rec(f, cs_exp(theta, e)) *)
  | cs_exp (theta, Fn(y, e))            = Fn(y, cs_exp(theta, e))
  | cs_exp (theta, Fnc(psi, e))         = Fnc(psi, cs_exp(theta, e))
  | cs_exp (theta, Box(names, M))       = Box(names, cs_normal(theta, M))
  | cs_exp (theta, Sbox(names, sigma))  = Sbox(names, cs_substitution(theta, sigma))
  | cs_exp (theta, Capp(e1, e2))        = Capp(cs_exp(theta, e1), cs_exp(theta, e2))
  | cs_exp (theta, Appc(e, Psi))        = Appc(cs_exp(theta, e), Psi)
  | cs_exp (theta, Aexp(e, tau))        = Aexp(cs_exp(theta, e), tau)
  | cs_exp (theta, Case(e, branches))   = Case(cs_exp(theta, e), map (fn b => cs_branch(theta, b)) branches)
  | cs_exp (theta, Let((x, e), e'))     = Let((x, cs_exp(theta, e)), cs_exp(theta, e'))
  | cs_exp (theta, If(e1, e2, e3))      = If(cs_exp(theta, e1), cs_exp(theta, e2), cs_exp(theta, e3))
  | cs_exp (theta, Op(p, exps))         = Op(p, map (fn e => cs_exp(theta, e)) exps)
  | cs_exp (theta, Equalp(e1, e2, Psi)) = Equalp(cs_exp(theta, e1), cs_exp(theta, e2), Psi)
  | cs_exp (theta, Num(i))              = Num(i)
  | cs_exp (theta, Boolean(b))          = Boolean(b)
and cs_branch (theta, Bbranch(names, M, e))     = Bbranch(names, M, cs_exp(theta, e))     (* FIXME rename to avoid capture *)
  | cs_branch (theta, Sbranch(names, sigma, e)) = Sbranch(names, sigma, cs_exp(theta, e)) (* FIXME rename to avoid capture *)
and cs_normal (theta, Lambda(y, N)) = Lambda(y, cs_normal(theta, N))
  | cs_normal (theta, Pair(M, N))   = Pair(cs_normal(theta, M), cs_normal(theta, N))
  | cs_normal (theta, Neutr(R))     = cs_neutral(theta, R)
and cs_neutral (theta, Mvar(u, sigma)) = 
    ((case get(u, theta) of Mrepl(M) => sim_os_normal(cs_substitution(theta, sigma), M)
                          | _        => raise runtimeError("unexpected"))
     handle notFound => Neutr(Mvar(u, sigma)))
  | cs_neutral (theta, Pvar(p, sigma)) =
    ((case get(p, theta) of Mrepl(Neutr(Ovar(x, i))) => sim_os_normal(cs_substitution(theta, sigma), Neutr(Ovar(x, i)))
                          | _                        => raise runtimeError("unexpected"))
     handle notFound => Neutr(Pvar(p, sigma)))
  | cs_neutral (theta, App(R, N)) =
    (case cs_neutral(theta, R) of Neutr(R')     => Neutr(App(R', cs_normal(theta, N)))
                                | Lambda(y, M') => os_normal(cs_normal(theta, N), 0, M')
                                | _             => raise runtimeError("unexpected"))
  | cs_neutral (theta, Fst(R)) = 
    (case cs_neutral(theta, R) of Neutr(R')    => Neutr(Fst(R'))
                                | Pair(M1, M2) => M1
                                | _            => raise runtimeError("unexpected"))
  | cs_neutral (theta, Snd(R)) = 
    (case cs_neutral(theta, R) of Neutr(R')    => Neutr(Snd(R'))
                                | Pair(M1, M2) => M2
                                | _            => raise runtimeError("unexpected"))
  | cs_neutral (theta, Ovar(x, i)) = Neutr(Ovar(x, i))
  | cs_neutral (theta, Const(c))   = Neutr(Const(c))
and cs_substitution (theta, Snull)          = Snull
  | cs_substitution (theta, SubM(sigma, N)) = SubM(cs_substitution(theta, sigma), cs_normal(theta, N))
  | cs_substitution (theta, SubR(sigma, R)) = 
    (case cs_neutral(theta, R) of 
         Neutr(R') => SubR(cs_substitution(theta, sigma), R')
       | M         => SubM(cs_substitution(theta, sigma), M))
  | cs_substitution (theta, Svar(s, rho))   = 
    ((case get(s, theta) of
          Srepl(sigma) => sim_os_substitution(cs_substitution(theta, rho), sigma)
        | _            => raise runtimeError("unexpected"))
     handle notFound => raise runtimeError("unexpected")) (* FIXME not sure this is ok *)
  | cs_substitution (theta, Id(psi))        = Id(psi)

(* PATTERN MATCHING *)
fun match_normal (Lambda(x, M), Lambda(x', N)) = match_normal(M, N)
  | match_normal (Pair(M1, N1), Pair(M2, N2))  = match_normal(M1, M2) @ match_normal(N1, N2)
  | match_normal (Neutr(R), Neutr(R'))         = match_neutral(R, R')
  | match_normal (_, _)                        = raise failedMatch
and match_neutral (Ovar(x, i), Ovar(x', i')) = if i = i' then [] else raise failedMatch
  | match_neutral (Const(c), Const(c'))      = if c = c' then [] else raise failedMatch
  | match_neutral (Mvar(u, pi), R)           = 
    if closed_neutral(R, pi) then [(Mrepl(Neutr(R)), u)] else raise failedMatch
  | match_neutral (Pvar(p, pi), Ovar(x, i))  = 
    if closed_neutral(Ovar(x, i), pi) then [(Mrepl(Neutr(Ovar(x, i))), p)] else raise failedMatch
  | match_neutral (Fst(R), Fst(R'))          = match_neutral(R, R')
  | match_neutral (Snd(R), Snd(R'))          = match_neutral(R, R')
  | match_neutral (App(R1, N1), App(R2, N2)) = match_neutral(R1, R2) @ match_normal(N1, N2)
  | match_neutral (_, _)                     = raise failedMatch
fun match_substitution (Snull, Snull)                  = []
  | match_substitution (SubM(sigma, M), SubM(rho, N))  = match_substitution(sigma, rho) @ match_normal(M, N)
  | match_substitution (SubR(sigma, R), SubR(rho, R')) = match_substitution(sigma, rho) @ match_neutral(R, R')
  | match_substitution (Svar(s, pi), rho)              = [(Srepl(rho), s)]
  | match_substitution (_, _)                          = raise failedMatch

fun match (b, []) = raise runtimeError("nonexhaustive match failure")
  | match (Box(names, M), Bbranch(names', M', e) :: tail) = 
    (cs_exp(match_normal(M', M), e) handle failedMatch => match(Box(names, M), tail))
  | match (Sbox(names, sigma), Sbranch(names', sigma', e) :: tail) = 
    (cs_exp(match_substitution(sigma', sigma), e) handle failedMatch => match(Sbox(names, sigma), tail))
  | match (_, _) = raise runtimeError("unexpected")

(* main evaluation functions *)
fun eval_primop (Add,     [Num(a),Num(b)])         = Num(a + b)
  | eval_primop (Mul,     [Num(a),Num(b)])         = Num(a * b)
  | eval_primop (Minus,   [Num(a),Num(b)])         = Num(a - b)
  | eval_primop (Div,     [Num(a),Num(b)])         = Num(a div b)
  | eval_primop (Andalso, [Boolean(a),Boolean(b)]) = Boolean(a andalso b)
  | eval_primop (Orelse,  [Boolean(a),Boolean(b)]) = Boolean(a orelse b)
  | eval_primop (Not,     [Boolean(a)])            = Boolean(not a)
  | eval_primop (Equal,   [Num(a),Num(b)])         = Boolean(a = b)
  | eval_primop (Equal,   [Boolean(a),Boolean(b)]) = Boolean(a = b)
  | eval_primop (primop,  args)                    = 
    raise runtimeError("op2str(Op) ^ called with arguments of type map ctyp2str args")

fun eval_exp (Rec(f,e))            = eval_exp(substitute_var_exp(Rec(f, e), f, e))
  | eval_exp (Capp(e1, e2))        = 
    (case eval_exp(e1) of
         Fn(y, e) => eval_exp(substitute_var_exp(eval_exp(e2), y, e))
       | _        => raise runtimeError("unexpected"))
  | eval_exp (Appc(e, Psi)) = 
    (case eval_exp(e) of
         Fnc(psi, e) => eval_exp(substitute_cvar_exp(Psi, psi, e))
       | _           => raise runtimeError("unexpected"))
  | eval_exp (Aexp(e, t))          = eval_exp(e)
  | eval_exp (Case(e, b))          = eval_exp(match(eval_exp(e), b))
  | eval_exp (Let((x, e), e'))     = eval_exp(substitute_var_exp(eval_exp(e), x, e'))
  | eval_exp (Op(p, exps))         = eval_primop(p, map eval_exp exps)
  | eval_exp (Equalp(Box(_, Neutr(R1)), Box(_, Neutr(R2)), _)) = Boolean(equal_neutral(R1, R2))
  | eval_exp (If(e1, e2, e3))      = (case eval_exp(e1) of 
                                          Boolean(true)  => eval_exp(e2)
                                        | Boolean(false) => eval_exp(e3)
                                        | _              => raise runtimeError("unexpected"))
  | eval_exp (e)                   = if isValue(e) then e else raise runtimeError("unexpected")

fun eval_exps (nil)                       = ()
  | eval_exps (Aexp(Rec(f,e), t) :: exps) = (Rec(f, e);
                                             print((name2str f) ^ " : " ^ (ctyp2str t) ^ "\n");
                                             eval_exps(map (fn x => substitute_var_exp(Rec(f, e), f, x)) exps))
  | eval_exps (e :: exps)                 = (print(exp2str(eval_exp(e)) ^ "\n"); eval_exps(exps))

fun eval (Prog(S, exps)) = eval_exps(exps)

end;
