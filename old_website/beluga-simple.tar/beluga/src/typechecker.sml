structure TypeChecker : sig 
    val typecheck : DataTypes.prog -> unit
    exception typeCheckError of string
    exception undefinedName of string
end
  = struct

open DataTypes
open Pretty

exception typeCheckError of string
exception undefinedName of string

val Sigma : sign list ref = ref []
val Gamma : ccontext ref = ref (Cctx([]))

(* utility functions for typechecking *)
local
    val c =  ref 0
in
fun fresh_name () = (c := !c + 1; Name("_x" ^ Int.toString(!c)))
end

fun nth (Ctx(Psi, (x, A)), i) = if i = 0 then A else nth(Psi, i - 1)
  | nth (Cnull, i)            = raise typeCheckError "unexpected error"
  | nth (Cvar(n), i)          = raise typeCheckError "unexpected error"

fun lookup ((name, x) :: t, n) = if name = n then x else lookup (t, n)
  | lookup ([], Name(n))       = raise undefinedName n

fun lookup_sign (Type(name) :: t, n)         = lookup_sign(t, n)
  | lookup_sign (Constant(name,typ) :: t, n) = if name = n then typ else lookup_sign (t, n)
  | lookup_sign ([], Name(n))                = raise typeCheckError "unexpected error"

fun rename_ctyp (n1, n2, Boxt(A, Psi))       = Boxt(A, rename_context(n1, n2, Psi))
  | rename_ctyp (n1, n2, Subst(Phi, Psi))    = Subst(rename_context(n1, n2, Phi), rename_context(n1, n2, Psi))
  | rename_ctyp (n1, n2, Carrow(tau1, tau2)) = Carrow(rename_ctyp(n1, n2, tau1), rename_ctyp(n1, n2, tau2))
  | rename_ctyp (n1, n2, Pi((psi, W), tau)) = 
    if psi = n1 then 
        Pi((psi, W), tau)
    else if psi = n2 then
        let
            val psi' = fresh_name()
            val tau' = rename_ctyp(psi, psi', tau)
        in
            Pi((psi', W), rename_ctyp(n1, n2, tau'))
        end
    else
        Pi((psi, W), rename_ctyp(n1, n2, tau))
  | rename_ctyp (n1, n2, Int)                = Int
  | rename_ctyp (n1, n2, Bool)               = Bool
and rename_context (n1, n2, Cnull)            = Cnull
  | rename_context (n1, n2, Cvar(psi))        = if psi = n1 then Cvar(n2) else Cvar(psi)
  | rename_context (n1, n2, Ctx(Psi, (x, A))) = Ctx(rename_context(n1, n2, Psi), (x, A))

(* substitution for context variables *)
fun substitute (Psi, psi, T) =
    case T of
        Int                => Int
      | Bool               => Bool
      | Boxt(A, Psi')      => Boxt(A, substitute_context(Psi, psi, Psi'))
      | Subst(Phi, Psi')   => Subst(substitute_context(Psi, psi, Phi), substitute_context(Psi, psi, Psi'))
      | Carrow(tau1, tau2) => Carrow(substitute(Psi, psi, tau1), substitute(Psi, psi, tau2))
      | Pi((psi', W), tau) => if psi = psi' then Pi((psi', W), tau) 
                              else
                                  let val psi'' = fresh_name() in 
                                      Pi((psi'', W), substitute(Psi, psi, rename_ctyp(psi', psi'', tau))) 
                                  end
and substitute_context (Psi, psi, Cnull)             = Cnull
  | substitute_context (Psi, psi, Cvar(psi'))        = if psi = psi' then Psi else Cvar(psi')
  | substitute_context (Psi, psi, Ctx(Psi', (x, A))) = Ctx(substitute_context(Psi, psi, Psi'), (x, A))

fun alpha_equivalent (Cnull, Cnull)       = true
  | alpha_equivalent (Cvar(n1), Cvar(n2)) = (n1 = n2)
  | alpha_equivalent (Ctx(Phi1, (x1, t1)), Ctx(Phi2, (x2, t2))) = (t1 = t2) andalso alpha_equivalent (Phi1, Phi2)
  | alpha_equivalent (_)                  = false

fun hat_equivalent (h, c) =
    let
        fun he ([], Cnull)                 = true
          | he ([g], Cvar(g'))             = g = g'
          | he (h :: t, Ctx(Phi, (x, A)))  = he(t, Phi)
          | he (_)                         = false
    in
        if he(List.rev h, c) then () else 
        raise typeCheckError("'" ^ names2str h ^ "' not equivalent to " ^ context2str c)
    end

fun distinct (L, [])            = true
  | distinct (L, ((n, t) :: l)) = ((lookup(L, n); false) handle undefinedName(_) => distinct(L, l))

fun subcontext (Psi, Snull)                   = Cnull
  (* REM x not really correct, but doesn't really matters since we use indices *)
  | subcontext (Psi, SubR(sigma, Ovar(x, i))) = Ctx(subcontext(Psi, sigma), (x, nth(Psi, i)))
  | subcontext (Cvar(psi), Id(psi'))          = Cvar(psi)
  | subcontext (Ctx(Psi, (x, A)), Id(psi))    = subcontext(Psi, Id(psi))
  | subcontext (Psi, sigma)                   = 
    raise typeCheckError("failed to extract subcontext of " ^ context2str(Psi) ^ " from " ^ sub2str(sigma))

(* schema checking *)
fun isin (A, Single(t))   = (A = t)
  | isin (A, Star(s))     = isin(A, s)
  | isin (A, Sum(s1, s2)) = isin(A, s1) orelse isin(A, s2)

fun schemacheck (O, Cnull, W)          = ()
  | schemacheck (Sctx(O), Cvar(n), W)  = 
    if lookup(O, n) = W then () 
    else raise typeCheckError("failed schema check for " ^ name2str(n) ^ ": expected: " ^ schema2str(W) ^ ", got: " ^ schema2str(lookup(O, n)))
  | schemacheck (O, Ctx(c, (x, A)), W) = 
    (if isin(A, W) then () 
     else raise typeCheckError("type " ^ typ2str(A) ^ " is not in schema " ^ schema2str(W)); schemacheck(O, c, W))

(* typechecking for object level *)
fun typecheck_normal (D, Psi, Lambda(n, M), Arrow(A,B)) = typecheck_normal(D, Ctx(Psi, (n, A)), M, B)
  | typecheck_normal (D, Psi, Pair(M1, M2), Cross(A1, A2)) = (typecheck_normal (D, Psi, M1, A1); typecheck_normal(D, Psi, M2, A2))
  | typecheck_normal (D, Psi, Neutr(R), P) = if typeof_neutral(D, Psi, R) = P then () else raise typeCheckError("type generated from neutral term " ^ neutral2str(R) ^ " (" ^ typ2str(typeof_neutral(D, Psi, R)) ^ ") does not check against " ^ typ2str(P))
  | typecheck_normal (D, Psi, M, A) = raise typeCheckError(normal2str(M) ^ " does not check against " ^ typ2str(A))
and typeof_neutral (D, Psi, Ovar(n, i)) = nth(Psi, i)
  | typeof_neutral (Mctx(D), Psi, Mvar(n, s)) = 
    (case lookup(D, n) of Mtyp(A, Phi) => (typecheck_substitution(Mctx(D), Psi, s, Phi); A)
                        | tau          => raise typeCheckError("inferred type " ^ mtyp2str(tau) ^ " for meta-variable " ^ neutral2str(Mvar(n, s))))
  | typeof_neutral (Mctx(D), Psi, Pvar(n, s)) = 
    (case lookup(D, n) of Ptyp(A, Phi) => (typecheck_substitution(Mctx(D), Psi, s, Phi); A)
                        | tau          => raise typeCheckError("inferred type " ^ mtyp2str(tau) ^ " for parameter " ^ neutral2str(Pvar(n, s))))
  | typeof_neutral (D, Psi, App(R, N)) = 
    (case typeof_neutral(D, Psi, R) of Arrow(A, B) => (typecheck_normal(D, Psi, N, A); B)
                                     | A           => raise typeCheckError("expected arrow type for " ^ neutral2str(R) ^ " inferred " ^ typ2str(A)))
  | typeof_neutral (D, Psi, Fst(R)) = 
    (case typeof_neutral(D, Psi, R) of Cross(A1, A2) => A1
                                     | A             => raise typeCheckError("expected product type for " ^ neutral2str(R) ^ " inferred " ^ typ2str(A)))
  | typeof_neutral (D, Psi, Snd(R)) = 
    (case typeof_neutral(D, Psi, R) of Cross(A1, A2) => A2
                                     | A             => raise typeCheckError("expected product type for " ^ neutral2str(R) ^ " inferred " ^ typ2str(A)))
  | typeof_neutral (D, Psi, Const(c)) = lookup_sign(!Sigma, c)
and typecheck_substitution (D, Psi, Snull, Cnull) = ()
  | typecheck_substitution (D, Psi, Id(psi), Cvar(psi')) = 
    let 
        fun pop_decl (Ctx(c,(n,t))) = pop_decl(c)
          | pop_decl (Cvar(n))      = n
          | pop_decl (Cnull)        = raise typeCheckError("no context variable to check Id against")
        val n = pop_decl(Psi)
    in
        if psi = n andalso psi = psi' then () 
        else raise typeCheckError("'Delta; " ^ name2str(n) ^ "|- id(" ^ name2str(psi) ^ ") <= " ^ name2str(psi') ^ "' failed")
    end
  | typecheck_substitution (Mctx(D), Psi, Svar(s, rho), Phi) =
    (case lookup(D, s) of Styp(Phi1, Phi2) => 
                          if alpha_equivalent(Phi1, Phi) then
                              typecheck_substitution(Mctx(D), Psi, rho, Phi2)
                          else raise typeCheckError(context2str(Phi1) ^ " not alpha-equivalent to " ^ context2str(Phi))
                        | tau => raise typeCheckError("inferred type " ^ mtyp2str(tau) ^ " for substitution variable " ^ sub2str(Svar(s, rho))))
  | typecheck_substitution (D, Psi, SubM(sigma, M), Ctx(Phi, (x, A))) = 
    (typecheck_substitution (D, Psi, sigma, Phi); typecheck_normal(D, Psi, M, A))
  | typecheck_substitution (D, Psi, SubR(sigma, R), Ctx(Phi, (x, A))) = 
    (typecheck_substitution (D, Psi, sigma, Phi); 
     if A = typeof_neutral(D, Psi, R) then () 
     else raise typeCheckError("synthesized type for " ^ neutral2str(R) ^ " not equal to expected " ^ typ2str(A)))
  | typecheck_substitution (D, Psi, sigma, Phi) = 
    raise typeCheckError("substitution " ^ sub2str(sigma) ^ " doesn't check against context " ^ context2str(Phi))

fun typecheck_normal_linear (Psi, Lambda(x, M), Arrow(A,B)) = 
    typecheck_normal_linear(Ctx(Psi, (x, A)), M, B)
  | typecheck_normal_linear (Psi, Pair(M, N), Cross(A, B)) = 
    let 
        val D1 = typecheck_normal_linear(Psi, M, A)
        val D2 = typecheck_normal_linear(Psi, N, B)
    in
        if distinct(D1, D2) then D1 @ D2
        else raise typeCheckError("pattern not linear: " ^ normal2str(Pair(M, N)))
    end
  | typecheck_normal_linear (Psi, Neutr(R), P) = 
    (case R of Mvar(u, pi) => [(u, Mtyp(P, subcontext(Psi, pi)))]
             | Pvar(p, pi) => [(p, Ptyp(P, subcontext(Psi, pi)))]
             | _           => 
               let 
                   val (P', D') = typeof_neutral_linear(Psi, R) 
               in
                   if P = P' then D' else 
                   raise typeCheckError("synthesized type for " ^ neutral2str(R) ^ " : " ^ typ2str(P') ^ " not equal to expected " ^ typ2str(P))
               end)
  | typecheck_normal_linear (Psi, M, A) = 
    raise typeCheckError(normal2str(M) ^ " does not check against type " ^ typ2str(A))
and typeof_neutral_linear (Psi, Ovar(n, i)) = (nth(Psi, i), [])
  | typeof_neutral_linear (Psi, App(R, N)) = 
    (case typeof_neutral_linear(Psi, R) of 
         (Arrow(A, B), D1) => let val D2 = typecheck_normal_linear(Psi, N, A)
                              in
                                  if distinct(D1, D2) then
                                      (B, D1 @ D2)
                                  else
                                      raise typeCheckError("pattern not linear: " ^ neutral2str(App(R, N)))
                              end
       | _                 => raise typeCheckError("expected arrow type for " ^ neutral2str(R)))
  | typeof_neutral_linear (Psi, Fst(R)) = 
    (case typeof_neutral_linear(Psi, R) of (Cross(A1, A2), D') => (A1, D')
                                         | (A, _)              => raise typeCheckError("expected cross type for " ^ neutral2str(R) ^ " inferred " ^ typ2str(A)))
  | typeof_neutral_linear (Psi, Snd(R)) = 
    (case typeof_neutral_linear(Psi, R) of (Cross(A1, A2), D') => (A2, D')
                                         | (A, _)              => raise typeCheckError("expected cross type for " ^ neutral2str(R) ^ " inferred " ^ typ2str(A)))
  | typeof_neutral_linear (Psi, Const(c)) = (lookup_sign(!Sigma, c), [])
  | typeof_neutral_linear (Psi, R) = raise typeCheckError("can't synthesize a type for " ^ neutral2str(R))
and typecheck_substitution_linear (Psi, Snull, Cnull) = []
  | typecheck_substitution_linear (Psi, Svar(s, rho), Phi) =
    [(s, Styp(Phi, subcontext(Psi, rho)))]
  | typecheck_substitution_linear (Psi, SubM(sigma, M), Ctx(Phi, (x, A))) = 
    let
        val D1 = typecheck_substitution_linear(Psi, sigma, Phi)
        val D2 = typecheck_normal_linear(Psi, M, A)
    in
        if distinct(D1, D2) then D1 @ D2
        else raise typeCheckError("pattern not linear: " ^ sub2str(SubM(sigma, M)))
    end
  | typecheck_substitution_linear (Psi, SubR(sigma, R), Ctx(Phi, (x, A))) = 
    let
        val D1      = typecheck_substitution_linear (Psi, sigma, Phi)
        val (A, D2) = typeof_neutral_linear(Psi, R)
    in
        if distinct(D1, D2) then D1 @ D2
        else raise typeCheckError("pattern not linear: " ^ sub2str(SubR(sigma, R)))
    end
  | typecheck_substitution_linear (Psi, sigma, Phi) = raise typeCheckError(sub2str(sigma) ^ " does not check against " ^ context2str(Phi))

(* typechecking for computational level *)
fun typecheck_exp (O as Sctx(O'), D, G as Cctx(G'), exp, tau) =
    case (exp, tau) of
        (Fnc(n1, e), Pi((n2, s), t)) => typecheck_exp(Sctx(O' @ [(n1, s)]), D, G, e, rename_ctyp(n2, n1, t))
      | (Rec(n, e), t)               => (typecheck_exp(O, D, Cctx(G' @ [(n, t)]), e, t);
                                         let val Cctx(l) = !Gamma in Gamma := Cctx(l @ [(n, t)]) end)
      | (Fn(n, e), Carrow(t1, t2))   => typecheck_exp(O, D, Cctx(G' @ [(n, t1)]), e, t2)
      | (Box(ns, n), Boxt(t, c))     => (hat_equivalent(ns, c); typecheck_normal(D, c, n, t))
      | (Sbox(ns, s), Subst(c1, c2)) => (hat_equivalent(ns, c2); typecheck_substitution(D, c2, s, c1))
      | (Case(e, bs), t1)            =>
        (case typeof_exp(O, D, G, e) of 
             Boxt(t2,c)   => (map (fn b => typecheck_branch(O, D, G, b, Boxt(t2,c), t1)) bs; ())
           | Subst(c1,c2) => (map (fn b => typecheck_branch(O, D, G, b, Subst(c1,c2), t1)) bs; ())
           | tau          => raise typeCheckError("pattern matching on a non box type: " ^ ctyp2str(tau)))
      | (If(e1, e2, e3), t)          => (typecheck_exp(O, D, G, e1, Bool); typecheck_exp(O, D, G, e2, t); typecheck_exp(O, D, G, e3, t))
      | (e, t)                       =>
        let 
            val t' = typeof_exp(O, D, G, e)
        in
            if t' = t then () 
            else raise typeCheckError("synthesized type for " ^ exp2str(e) ^ " : " ^ ctyp2str(t') ^ " not equal to expected " ^ ctyp2str(t))
        end
and typecheck_branch (O, Mctx(D), G, Bbranch(names, M, e), Boxt(A, Psi), tau) = 
    (hat_equivalent(names, Psi);
     let 
         val D' = typecheck_normal_linear(Psi, M, A)
     in
         typecheck_exp(O, Mctx(D @ D'), G, e, tau)
     end)
  | typecheck_branch (O, Mctx(D), G, Sbranch(names, sigma, e), Subst(Phi, Psi), tau) = 
    (hat_equivalent(names, Psi); 
     let
         val D' = typecheck_substitution_linear(Psi, sigma, Phi)
     in 
         typecheck_exp(O, Mctx(D @ D'), G, e, tau)
     end)
  | typecheck_branch (_, _, _, b, tau, tau') = raise typeCheckError(branch2str(b) ^ " does not typecheck against type : " ^ ctyp2str(tau) ^ " <= " ^ ctyp2str(tau'))
and typeof_exp (O, D as Mctx(D'), G as Cctx(G'), exp) =
    case exp of 
        Aexp(e, t)     => (typecheck_exp(O,D,G,e,t); t)
      | Var(n)         => lookup(G', n)
      | Appc(e,c)      => (case typeof_exp(O, D, G, e) of 
                               Pi((n,s),t) => (schemacheck(O, c, s); substitute(c,n,t))
                             | _           => raise typeCheckError("expected Pi type for " ^ exp2str(e)))
      | Capp(e1, e2)   => (case typeof_exp(O, D, G, e1) of 
                               Carrow(t2, t1) => (typecheck_exp (O, D, G, e2, t2); t1)
                             | _              => raise typeCheckError("expected arrow type for " ^ exp2str(e1)))
      | Op(prim, args) =>
        (case prim of
             (Add | Mul | Minus | Div) => (typecheck_exp(O, D, G, List.nth(args, 0), Int);
                                           typecheck_exp(O, D, G, List.nth(args, 1), Int); Int)
           | (Andalso | Orelse)        => (typecheck_exp(O, D, G, List.nth(args, 0), Bool);
                                           typecheck_exp(O, D, G, List.nth(args, 1), Bool); Bool)
           | Not                       => (typecheck_exp(O, D, G, List.nth(args, 0), Bool); Bool)
           | Equal                     => 
             (typecheck_exp(O, D, G, List.nth(args, 1), typeof_exp(O, D, G, List.nth(args, 0))); Bool))
      | Let((n, e), e')    => typeof_exp(O, D, Cctx((n, typeof_exp(O, D, Cctx(G'), e)) :: G'), e')
      | Equalp(Box(ns1, Neutr(R1)), Box(ns2, Neutr(R2)), Psi) =>
        (hat_equivalent(ns1, Psi); hat_equivalent(ns2, Psi);
         if typeof_neutral(D, Psi, R1) = typeof_neutral(D, Psi, R2) then 
             Bool
         else
             raise typeCheckError("synthesized types for " ^ neutral2str(R1) ^ " and " ^ neutral2str(R2) ^ " are not the same"))
      | Num(_)         => Int
      | Boolean(_)     => Bool
      | e              => raise typeCheckError("tried to synthesize a type from " ^ exp2str(e))

fun typeof_exps (nil)         = ()
  | typeof_exps (exp :: exps) = (typeof_exp(Sctx([]), Mctx([]), !Gamma, exp); typeof_exps(exps))

fun typecheck (Prog(S, exps)) = (Sigma := S; Gamma := Cctx([]); typeof_exps(exps))

end;
