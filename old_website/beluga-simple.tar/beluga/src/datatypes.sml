signature DATATYPES = sig
datatype prog = Prog of (sign list) * (exp list)
     and sign = Type of name
              | Constant of name * typ
     and exp = Var of name
             | Rec of name * exp
             | Fn of name * exp
             | Fnc of name * exp
             | Box of name list * normal
             | Sbox of name list * subs
             | Capp of exp * exp                (* computational level application *)
             | Appc of exp * context
             | Aexp of exp * ctyp               (* annotated expression *)
             | Case of exp * branch list
             | Let of (name * exp) * exp
             | Op of primop * exp list
             | Equalp of exp * exp * context
             | If of exp * exp * exp
             | Num of int
             | Boolean of bool
     and name     = Name of string
     and ccontext = Cctx of (name * ctyp) list  (* computational level contexts *)
     and primop   = Add | Mul | Minus | Div | Andalso | Orelse | Not | Equal
     and branch   = Bbranch of name list * normal * exp
                  | Sbranch of name list * subs * exp
     and ctyp     = Boxt of typ * context       (* computational level types *)
                  | Subst of context * context
                  | Carrow of ctyp * ctyp
                  | Pi of (name * schema) * ctyp
                  | Int
                  | Bool

     (* object level *)
     and typ      = Atom of name | Arrow of typ * typ | Cross of typ * typ
     and normal   = Lambda of name * normal | Pair of normal * normal | Neutr of neutral
     and neutral  = Ovar of name * int          (* object level variable *)
                  | Mvar of name * subs         (* meta variable *)
                  | Pvar of name * subs         (* parameter variable *)
                  | App of neutral * normal
                  | Fst of neutral
                  | Snd of neutral
                  | Const of name
     and subs     = Snull
                  | SubM of subs * normal
                  | SubR of subs * neutral
                  | Svar of name * subs
                  | Id of name
     and context  = Cnull
                  | Cvar of name
                  | Ctx of context * (name * typ)
     and mtyp     = Mtyp of typ * context
                  | Ptyp of typ * context
                  | Styp of context * context
     and mcontext = Mctx of (name * mtyp) list
     and scontext = Sctx of (name * schema) list
     and schema   = Single of typ
                  | Star of schema
                  | Sum of schema * schema
     and replacement = Mrepl of normal
                     | Srepl of subs
end;

structure DataTypes : DATATYPES = struct
datatype prog = Prog of (sign list) * (exp list)
     and sign = Type of name
              | Constant of name * typ
     and exp = Var of name
             | Rec of name * exp
             | Fn of name * exp
             | Fnc of name * exp
             | Box of name list * normal
             | Sbox of name list * subs
             | Capp of exp * exp                (* computational level application *)
             | Appc of exp * context
             | Aexp of exp * ctyp               (* annotated expression *)
             | Case of exp * branch list
             | Let of (name * exp) * exp
             | Op of primop * exp list
             | Equalp of exp * exp * context
             | If of exp * exp * exp
             | Num of int
             | Boolean of bool
     and name     = Name of string
     and ccontext = Cctx of (name * ctyp) list  (* computational level contexts *)
     and primop   = Add | Mul | Minus | Div | Andalso | Orelse | Not | Equal
     and branch   = Bbranch of name list * normal * exp
                  | Sbranch of name list * subs * exp
     and ctyp     = Boxt of typ * context       (* computational level types *)
                  | Subst of context * context
                  | Carrow of ctyp * ctyp
                  | Pi of (name * schema) * ctyp
                  | Int
                  | Bool

     (* object level *)
     and typ      = Atom of name | Arrow of typ * typ | Cross of typ * typ
     and normal   = Lambda of name * normal | Pair of normal * normal | Neutr of neutral
     and neutral  = Ovar of name * int          (* object level variable *)
                  | Mvar of name * subs         (* meta variable *)
                  | Pvar of name * subs         (* parameter variable *)
                  | App of neutral * normal
                  | Fst of neutral
                  | Snd of neutral
                  | Const of name
     and subs     = Snull
                  | SubM of subs * normal
                  | SubR of subs * neutral
                  | Svar of name * subs
                  | Id of name
     and context  = Cnull
                  | Cvar of name
                  | Ctx of context * (name * typ)
     and mtyp     = Mtyp of typ * context
                  | Ptyp of typ * context
                  | Styp of context * context
     and mcontext = Mctx of (name * mtyp) list
     and scontext = Sctx of (name * schema) list
     and schema   = Single of typ
                  | Star of schema
                  | Sum of schema * schema
     and replacement = Mrepl of normal
                     | Srepl of subs
end;
