(* -*- sml-yacc -*- *)

open DataTypes

exception ParseError of string

fun index_of (Name(n), [], offset) = raise TypeChecker.undefinedName n
  | index_of (n, names, offset)    = 
    if n = List.last(names) then
        offset 
    else 
        index_of (n, List.take(names, List.length(names) - 1), offset + 1)

fun index_normal (names, Lambda(x, M))       = Lambda(x, index_normal(names @ [x], M))
  | index_normal (names, Pair(M, N))         = Pair(index_normal(names, M), index_normal(names, N))
  | index_normal (names, Neutr(R))           = Neutr(index_neutral(names, R))
and index_neutral (names, Ovar(x,i))         = Ovar(x, index_of (x, names, 0))
  | index_neutral (names, Mvar(u, sigma))    = Mvar(u, index_subs(names, sigma))
  | index_neutral (names, Pvar(p, sigma))    = Pvar(p, index_subs(names, sigma))
  | index_neutral (names, App(R, N))         = App(index_neutral(names, R), index_normal(names, N))
  | index_neutral (names, Fst(R))            = Fst(index_neutral(names, R))
  | index_neutral (names, Snd(R))            = Snd(index_neutral(names, R))
  | index_neutral (names, Const(c))          = Const(c)
and index_subs (names, Snull)                = Snull
  | index_subs (names, SubM(sigma, M))       = SubM(index_subs(names, sigma), index_normal(names, M))
  | index_subs (names, SubR(sigma, R))       = SubR(index_subs(names, sigma), index_neutral(names, R))
  | index_subs (names, Svar(s, sigma))       = Svar(s, index_subs(names, sigma))
  | index_subs (names, Id(n))                = Id(n)

fun transform_let ((Var(x), e) :: t, e')            = Let((x, e), transform_let(t, e'))
  | transform_let ((Box(names, M), e) :: t, e')     = 
    Case(e, [Bbranch(names, index_normal(names, M), transform_let(t, e'))])
  | transform_let ((Sbox(names, subs), e) :: t, e') = 
    Case(e, [Sbranch(names, index_subs(names, subs), transform_let(t, e'))])
  | transform_let ([], e')                          = e'
  | transform_let (_, _)                            = raise ParseError("unexpected")

(* keep lists for the constants and atoms names *)
(* FIXME: replace with a parsing environment passed through nonterminals *)
val A : string list ref = ref []
val C : string list ref = ref []

fun resetParserState () = (A := []; C := [])

fun member (name, [])     = false
  | member (name, h :: t) = (name = h) orelse member(name, t)

(* Following adapted, ultimately, from the SML/NJ parser (via Tolmach/Oliva's RML). *)
structure F = Fixity

(* cf. Definition, p. 72, p. 67, ...? *)
fun fixityfn string = case string of
        "+" => F.infixleft 6
      | "-" => F.infixleft 6
      | "*" => F.infixleft 7
      | "/" => F.infixleft 7
      | "div" => F.infixleft 7
      | "mod" => F.infixleft 7
      | "<" => F.infixleft 4
      | ">" => F.infixleft 4
      | "<=" => F.infixleft 4
      | ">=" => F.infixleft 4
      | "^" => F.infixleft 4   (* can't find in Definition *)
      | "<>" => F.infixleft 4   (* can't find in Definition *)
      | "=" => F.infixleft 4   (* p. 67 *)
      | "andalso" => F.infixleft 0
      | "orelse" => F.infixleft 0
      | _ => F.NONfix

fun unflatten exps =
    let val exp = Precedence.parse
                              (fn string => string)
                              {apply= fn (e1, e2) => Capp(e1, e2),
                               applyInfix= fn (e2, e1, e3) =>
                                  let in case e2 of Var(Name name) =>
                                      let val primop =
                                          case name of
                                              "+" => Add
                                            | "-" => Minus
                                            | "*" => Mul
                                            | "/" => Div
                                            | "andalso" => Andalso
                                            | "orelse" => Orelse
                                            | "=" => Equal
                                            | _ => raise ParseError ("operator precedence problem")
                                      in
                                            Op(primop, [e1, e3])
                                      end
                                  end
                               }
                               (exps, fixityfn)
    in
        exp
    end

%%

%verbose

%pos int

%term EOF | COLON | SEMICOLON | INT | BOOL |
      EQUAL | VAL | REC | BOX | SBOX | BOXEQ |
      LET | IN | END |
      IF | THEN | ELSE |
      CASE | OF | BAR | FNC | FN |
      LPAREN | RPAREN | LBRACKET | RBRACKET |
      DOT | ARROW | DARROW | BACKSLASH |
      BOOLEAN of bool | NUM of int | NAME of string |
      ADD | SUB | STAR | DIV | AND | OR | NOT |
      COMMA | UNDERSCORE | IDENT |
      ORELSE | ANDALSO | FST | SND | TYPE |
      LBRACE | RBRACE | APP | MUL

%nonterm PROG of prog | EXP of exp | aexp of {item: exp, fixity : string option, loc : unit} list  | 
         aaexp of exp | EXPS of exp list |
         BRANCHES of branch list | BRANCH of branch | CTX of context | 
         atomictyp of typ | producttyp of typ | TYP of typ |
         nameish of string |
         NAMES of name list |
         NORMAL of normal | nonappNORMAL of normal | 
         SUBS of subs | NTS of (name * typ) list |
         CTYP of ctyp |
         NEUTRAL of neutral | nonappNEUTRAL of neutral |
         SIGLINES of sign list | SIGLINE of sign |
         DECLS of (exp * exp) list | DECL of exp * exp |
         SCHEMA of schema

%name fphoas

%noshift EOF
%eop EOF

%start PROG

%arg (fileName) : string

%nonassoc COLON
%left EQUAL
%left ADD SUB ORELSE
%left DIV MUL ANDALSO
%left NOT
(* %nonassoc APP (* p.30 of ug.pdf, doesn't work *) *)

%%

PROG : SIGLINES EXPS (let in resetParserState(); Prog(SIGLINES, EXPS) end)

SIGLINES :                  ([])
         | SIGLINE SIGLINES (SIGLINE::SIGLINES)

SIGLINE : NAME COLON TYPE DOT (A := NAME :: !A; Type(Name(NAME)))
        | NAME COLON TYP DOT  (C := NAME :: !C; Constant(Name(NAME), TYP))

EXPS : EXP SEMICOLON      ([EXP])
     | EXP SEMICOLON EXPS (EXP::EXPS)

aaexp : LPAREN EXP RPAREN                   (EXP)
      | NUM                                 (Num(NUM))
      | BOOLEAN                             (Boolean(BOOLEAN))
      | LET DECLS IN EXP END                (transform_let(DECLS, EXP))
      | LPAREN EXP COLON CTYP RPAREN        (Aexp(EXP, CTYP))
      | BOX LPAREN NAMES DOT NORMAL RPAREN  (Box(NAMES, index_normal(NAMES, NORMAL)))
      | SBOX LPAREN NAMES DOT SUBS RPAREN   (Sbox(NAMES, index_subs(NAMES, SUBS)))
      | NAME LBRACKET CTX RBRACKET          (Appc(Var(Name(NAME)), CTX))
      | aaexp LBRACKET CTX RBRACKET         (Appc(aaexp, CTX))

nameish : NAME    (NAME)
        | ADD     ("+")
        | SUB     ("-")
        | STAR    ("*")
        | DIV     ("/")
        | EQUAL   ("=")
        | ANDALSO ("andalso")
        | ORELSE  ("orelse")

aexp : aaexp          ([{item= aaexp,  loc= (),  fixity= NONE}])
     | nameish        ([{item= Var(Name(nameish)), loc= (), fixity= SOME (nameish)}])
     | aaexp aexp     ({item= aaexp,  loc= (),  fixity= NONE} :: aexp)
     | nameish aexp   ({item= Var(Name(nameish)), loc= (), fixity= SOME (nameish)} :: aexp)

EXP : REC NAME COLON CTYP EQUAL EXP       (Aexp(Rec(Name(NAME), EXP), CTYP))
    | aexp                                (unflatten aexp)
    | FN NAME DARROW EXP                  (Fn(Name(NAME), EXP))
    | FNC NAME DARROW EXP                 (Fnc(Name(NAME), EXP))
(*    | EXP ADD EXP %prec ADD               (Op(Add, [EXP1, EXP2]))
    | EXP SUB EXP %prec SUB               (Op(Minus, [EXP1, EXP2]))
    | EXP STAR EXP %prec MUL              (Op(Mul, [EXP1, EXP2]))
    | EXP DIV EXP %prec DIV               (Op(Div, [EXP1, EXP2]))
    | EXP EQUAL EXP   %prec EQUAL         (Op(Equal, [EXP1, EXP2]))
    | EXP ANDALSO EXP %prec ANDALSO       (Op(Andalso, [EXP1, EXP2]))
    | EXP ORELSE EXP  %prec ORELSE        (Op(Orelse, [EXP1, EXP2]))
*)

    | BOXEQ LPAREN LBRACKET CTX RBRACKET COMMA EXP COMMA EXP RPAREN (Equalp(EXP1, EXP2, CTX))
    | NOT EXP         %prec NOT           (Op(Not, [EXP]))
    | IF EXP THEN EXP ELSE EXP            (If(EXP1, EXP2, EXP3))
    | CASE EXP OF BRANCHES                (Case(EXP, BRANCHES))

DECLS : DECL       ([DECL])
      | DECL DECLS (DECL::DECLS)

DECL : VAL NAME EQUAL EXP                               ((Var(Name(NAME)), EXP))
     | VAL BOX LPAREN NAMES DOT NORMAL RPAREN EQUAL EXP ((Box(NAMES, NORMAL), EXP))
     | VAL SBOX LPAREN NAMES DOT SUBS RPAREN EQUAL EXP  ((Sbox(NAMES, SUBS), EXP))

BRANCHES : BRANCH              ([BRANCH])
         | BRANCH BAR BRANCHES (BRANCH::BRANCHES)

BRANCH : BOX LPAREN NAMES DOT NORMAL RPAREN DARROW EXP (Bbranch(NAMES, index_normal(NAMES, NORMAL), EXP))
       | SBOX LPAREN NAMES DOT SUBS RPAREN DARROW EXP  (Sbranch(NAMES, index_subs(NAMES, SUBS), EXP))

NAMES :                  ([])
      | NAME             ([Name(NAME)])
      | NAME COMMA NAMES (Name(NAME)::NAMES)

CTYP : NAME LBRACKET CTX RBRACKET            (if member(NAME, !A) then Boxt(Atom(Name(NAME)), CTX) else Subst(Cvar(Name(NAME)), CTX))
      (* avoids the reduce/reduce conflict between the next two rules if the first token is a NAME *)
     | TYP LBRACKET CTX RBRACKET             (Boxt(TYP, CTX))
     | CTX LBRACKET CTX RBRACKET             (Subst(CTX1, CTX2))
     | CTYP ARROW CTYP                       (Carrow(CTYP1, CTYP2))
     | LBRACE NAME COLON SCHEMA RBRACE CTYP  (Pi((Name(NAME), SCHEMA), CTYP))
     | LPAREN CTYP RPAREN                    (CTYP)
     | INT                                   (Int)
     | BOOL                                  (Bool)

SUBS : DOT                         (Snull)
     | IDENT LPAREN NAME RPAREN    (Id(Name(NAME)))
     | NAME LBRACKET SUBS RBRACKET (Svar(Name(NAME), SUBS))
     | SUBS SEMICOLON NORMAL       (SubM(SUBS, NORMAL))
     | SUBS COMMA NEUTRAL          (SubR(SUBS, NEUTRAL))

NORMAL : BACKSLASH NAME DOT NORMAL         (Lambda(Name(NAME), NORMAL))
       | LPAREN NORMAL COMMA NORMAL RPAREN (Pair(NORMAL1, NORMAL2))
       | NEUTRAL                           (Neutr(NEUTRAL))
       | LPAREN NORMAL RPAREN              (NORMAL)

nonappNORMAL : BACKSLASH NAME DOT NORMAL         (Lambda(Name(NAME), NORMAL))
       | LPAREN NORMAL COMMA NORMAL RPAREN (Pair(NORMAL1, NORMAL2))
       | nonappNEUTRAL                           (Neutr(nonappNEUTRAL))
       | LPAREN NORMAL RPAREN              (NORMAL)

nonappNEUTRAL : NAME LBRACKET SUBS RBRACKET  (if NAME >= "a" then Pvar(Name(NAME), SUBS) else Mvar(Name(NAME), SUBS))
        | LPAREN NEUTRAL RPAREN        (NEUTRAL)
        | NAME                         (if member(NAME,!C) then Const(Name(NAME)) else Ovar(Name(NAME), 0))
        | FST NEUTRAL                  (Fst(NEUTRAL))
        | SND NEUTRAL                  (Snd(NEUTRAL))

NEUTRAL : nonappNEUTRAL       (nonappNEUTRAL)
        | NEUTRAL nonappNORMAL               (App(NEUTRAL, nonappNORMAL))

CTX : NAME                      (Cvar(Name(NAME))) 
    | CTX COMMA NAME COLON TYP  (Ctx(CTX,(Name(NAME),TYP)))
    | NAME COLON TYP            (Ctx(Cnull,(Name(NAME),TYP)))
    |                           (Cnull)

SCHEMA : LPAREN SCHEMA RPAREN STAR (Star(SCHEMA))
       | SCHEMA ADD SCHEMA         (Sum(SCHEMA1, SCHEMA2))
       | TYP                       (Single(TYP))

atomictyp : NAME                        (Atom(Name(NAME)))
          | LPAREN TYP RPAREN           (TYP)

producttyp : atomictyp                 (atomictyp)
           | producttyp STAR atomictyp (Cross(producttyp, atomictyp))

TYP : producttyp            (producttyp)
    | producttyp ARROW TYP  (Arrow(producttyp, TYP))

