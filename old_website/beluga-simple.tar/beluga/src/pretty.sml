structure Pretty : sig 
    val prog2str     : DataTypes.prog     -> string
    val exp2str      : DataTypes.exp      -> string
    val branch2str   : DataTypes.branch   -> string
    val sub2str      : DataTypes.subs     -> string
    val normal2str   : DataTypes.normal   -> string
    val neutral2str  : DataTypes.neutral  -> string
    val context2str  : DataTypes.context  -> string
    val name2str     : DataTypes.name     -> string
    val names2str     : DataTypes.name list -> string
    val ctyp2str     : DataTypes.ctyp     -> string
    val typ2str      : DataTypes.typ      -> string
    val schema2str   : DataTypes.schema   -> string
    val primop2str   : DataTypes.primop   -> string
    val mtyp2str     : DataTypes.mtyp     -> string
    val mcontext2str : DataTypes.mcontext -> string
end
  = struct

open DataTypes

fun separator c sl = 
    List.foldr (fn (x,y) => if (y = "") then x else x^c^y) "" sl

fun prog2str (Prog(x, y))              = "Prog('signature', " ^ String.concat(map (fn e => "\n" ^ exp2str e) y) ^ ")"
and exp2str (Var(Name(x)))             = "Var(" ^ x ^ ")"
  | exp2str (Rec(Name(x), y))          = "Rec(" ^ x ^ ", " ^ (exp2str y) ^ ")"
  | exp2str (Fn(Name(x), y))           = "Fn(" ^ x ^ ", "  ^ (exp2str y) ^ ")"
  | exp2str (Fnc(Name(x), y))          = "Fnc(" ^ x ^ ", " ^ (exp2str y) ^ ")"
  | exp2str (Box(x, y))                = "Box("  ^ names2str(x) ^ ". " ^(normal2str y) ^ ")"
  | exp2str (Sbox(x, y))               = "Sbox(" ^ names2str(x) ^ ". " ^ (sub2str y) ^ ")"
  | exp2str (Capp(x,y))                = "Capp(" ^ exp2str(x) ^ ", " ^ exp2str(y) ^ ")"
  | exp2str (Appc(x,y))                = "Appc(" ^ exp2str(x) ^ ", " ^ context2str(y) ^ ")"
  | exp2str (Aexp(x, y))               = exp2str(x) ^ " : " ^ (ctyp2str y)
  | exp2str (Case(x, y))               = "Case(" ^ (exp2str x) ^ ", " ^ (concat (map branch2str y)) ^ ")"
  | exp2str (Let((x, y), z))           = "Let(" ^  name2str(x) ^ " = " ^ exp2str(y) ^ ", " ^ exp2str(z) ^ ")"
  | exp2str (If(x, y, z))              = "If(" ^  exp2str(x) ^ ", " ^ exp2str(y) ^ ", " ^ exp2str(z) ^ ")"
  | exp2str (Op(primop, y))            = "(Primop:" ^ (primop2str primop) ^ " " ^ (concat (map exp2str y)) ^ ")"
  | exp2str (Equalp(x, y, z))          = "Equalp(" ^ exp2str(x) ^ ", " ^ exp2str(y) ^ ", " ^ context2str(z) ^ ")"
  | exp2str (Num(x))                   = Int.toString x
  | exp2str (Boolean(x))               = Bool.toString x
and branch2str (Bbranch(x, y, z))      = "\n\tBox(" ^ names2str x ^ ". " ^ normal2str y ^ ") => " ^ exp2str z ^ ")"
  | branch2str (Sbranch(x, y, z))      = "\n\tSbox(" ^ names2str x ^ ". " ^ sub2str y ^ ") => " ^ exp2str z ^ ")"
and sub2str (Snull)                    = "Snull"
  | sub2str (SubM(x,y))                = (sub2str x) ^ "; " ^ (normal2str y)
  | sub2str (SubR(x,y))                = (sub2str x) ^ ", " ^ (neutral2str y)
  | sub2str (Svar(Name(x),y))          = "Svar(" ^ x ^ ", " ^ (sub2str y) ^ ")"
  | sub2str (Id(Name(n)))              = "Id(" ^ n ^ ")"
and normal2str (Lambda(Name(x),y))     = "Lambda(" ^ x ^ ", " ^ (normal2str y) ^ ")"
  | normal2str (Pair(x,y))             = "Pair(" ^ (normal2str x) ^ "," ^ (normal2str y) ^ ")"
  | normal2str (Neutr(x))              = "Neutr(" ^ (neutral2str x) ^ ")"
and neutral2str (Ovar(Name(x), i))     = "Ovar(" ^ x ^ ")"
  | neutral2str (Mvar(Name(x), y))     = "Mvar(" ^ x ^ "[" ^ (sub2str y) ^ "])"
  | neutral2str (Pvar(Name(x), y))     = "Pvar(" ^ x ^ ", " ^ (sub2str y) ^ ")"
  | neutral2str (App(x,y))             = "App(" ^ (neutral2str x) ^ ", " ^ (normal2str y) ^ ")"
  | neutral2str (Fst(x))               = "Fst(" ^ (neutral2str x) ^ ")"
  | neutral2str (Snd(x))               = "Snd(" ^ (neutral2str x) ^ ")"
  | neutral2str (Const(Name(x)))       = "Const(" ^ x ^ ")"
and context2str (Cnull)                = "Cnull"
  | context2str (Cvar(Name(x)))        = "Cvar(" ^ x ^ ")"
  | context2str (Ctx(x, (Name(y), z))) = "Ctx(" ^ (context2str x) ^ ", " ^ y ^ ":" ^ (typ2str z) ^ ")"
and name2str (Name(x))                 = x
and ctyp2str (Boxt(x,y))               = "Boxt(" ^ (typ2str x) ^ ", " ^ (context2str y) ^ ")"
  | ctyp2str (Subst(x,y))              = "Subst(" ^ (context2str x) ^ ", " ^ (context2str y) ^ ")"
  | ctyp2str (Carrow(x,y))             = "Carrow(" ^ (ctyp2str x) ^ ", " ^ (ctyp2str y) ^ ")"
  | ctyp2str (Pi((Name(x), y), z))     = "Pi(" ^ x ^ ":" ^ (schema2str y) ^ ", " ^ (ctyp2str z) ^ ")"
  | ctyp2str (Int)                     = "Int"
  | ctyp2str (Bool)                    = "Bool"
and typ2str (Atom(Name(x)))            = "Atom(" ^ x ^ ")"
  | typ2str (Arrow(x,y))               = "Arrow(" ^ (typ2str x) ^ ", " ^ (typ2str y) ^ ")"
  | typ2str (Cross(x,y))               = "Cross(" ^ (typ2str x) ^ ", " ^ (typ2str y) ^ ")"
and schema2str (Single(x))             = "Single(" ^ (typ2str x) ^ ")"
  | schema2str (Star(x))               = "Star(" ^ (schema2str x) ^ ")"
  | schema2str (Sum(x,y))              = "Sum(" ^ (schema2str x) ^ ", " ^ (schema2str y) ^ ")"
and primop2str (Add)                   = "Add"
  | primop2str (Mul)                   = "Mul"
  | primop2str (Minus)                 = "Minus"
  | primop2str (Div)                   = "Div"
  | primop2str (Andalso)               = "Andalso"
  | primop2str (Orelse)                = "Orelse"
  | primop2str (Not)                   = "Not"
  | primop2str (Equal)                 = "Equal"
and mcontext2str (Mctx(D))             =
    let 
        fun mc2str ([])                = ""
          | mc2str ([(Name(n), m)])    = n ^ ":" ^ mtyp2str(m)
          | mc2str ((Name(n), m) :: t) = n ^ ":" ^ mtyp2str(m) ^ ", " ^ mc2str(t)
    in
        "Mctx(" ^ mc2str(D) ^ ")"
    end
and mtyp2str (Mtyp(x, y))              = "Boxt(" ^ (typ2str x) ^ ", " ^ (context2str y) ^ ")"
  | mtyp2str (Ptyp(x, y))              = "Boxt(" ^ (typ2str x) ^ ", " ^ (context2str y) ^ ")"
  | mtyp2str (Styp(x, y))              = "Subst(" ^ (context2str x) ^ ", " ^ (context2str y) ^ ")"
and names2str (l) = separator ", " (map name2str l)

end;
