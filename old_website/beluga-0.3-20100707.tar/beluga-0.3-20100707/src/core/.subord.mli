val dump : bool ref

val clearMemoTable : unit -> unit   (* erase is_subordinate_to memo table *)
val sully : unit -> unit   (* mark is_subordinate_to memo table as dirty *)
                           (* (currently, just calls clearMemoTable) *)

val dump_subord : unit -> unit

val is_subordinate_to : Id.cid_typ -> Id.cid_typ -> bool  (* memoizing *)
